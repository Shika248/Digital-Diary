export interface JournalPrompt {
  id: string;
  category: 'Gratitude' | 'Reflection' | 'Clarity' | 'Growth' | 'Creativity';
  prompt: string;
}

export const JOURNAL_PROMPTS: JournalPrompt[] = [
  {
    id: 'p1',
    category: 'Gratitude',
    prompt: 'What are three quiet, overlooked moments from today that brought you peace?',
  },
  {
    id: 'p2',
    category: 'Gratitude',
    prompt: 'Who showed you kindness or helped you recently, and how did it affect your day?',
  },
  {
    id: 'p3',
    category: 'Reflection',
    prompt: 'What was the most challenging decision you faced today, and how do you feel about the choice you made?',
  },
  {
    id: 'p4',
    category: 'Reflection',
    prompt: 'What is something you learned about yourself this week that surprised you?',
  },
  {
    id: 'p5',
    category: 'Clarity',
    prompt: 'If you could pause everything for one hour right now, what would your mind most want to do?',
  },
  {
    id: 'p6',
    category: 'Clarity',
    prompt: 'What thought or obligation has been occupying too much of your mental bandwidth today?',
  },
  {
    id: 'p7',
    category: 'Growth',
    prompt: 'What small step can you take tomorrow toward a goal that feels meaningful to you?',
  },
  {
    id: 'p8',
    category: 'Growth',
    prompt: 'Describe a mistake you made recently and what wisdom you gained from navigating through it.',
  },
  {
    id: 'p9',
    category: 'Creativity',
    prompt: 'Describe your surroundings right now using all five senses in rich vivid detail.',
  },
  {
    id: 'p10',
    category: 'Creativity',
    prompt: 'Write a letter to your future self one year from today describing where you hope your heart is.',
  },
];
