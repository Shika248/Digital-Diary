import { DiaryEntry } from '../types';

export const INITIAL_ENTRIES: DiaryEntry[] = [
  {
    id: 'entry-1',
    title: 'A Morning of Deep Focus and Fresh Perspective',
    content: `The morning began with an unusual stillness. The early autumn air carries that crisp hint of change, and sunlight filtered through the blinds creating soft geometric patterns across my desk.

### Today's Anchors
- **Espresso & Notebook**: Spent 20 minutes without screens simply journaling ideas before opening emails.
- **Architectural Clarity**: Finally unblocked the solution to the project structure. The simpler approach was right in front of me all along.
- **Afternoon Walk**: Took a detour through the botanical gardens. The leaves are just beginning to turn amber.

> "Simplicity is the prerequisite for reliability."

I feel grounded today. It's so easy to let urgency masquerade as importance, but preserving quiet mornings makes all the difference in keeping centered.`,
    date: '2026-09-12',
    time: '09:15',
    createdAt: new Date('2026-09-12T09:15:00').getTime(),
    updatedAt: new Date('2026-09-12T09:15:00').getTime(),
    mood: 'inspired',
    weather: 'sunny',
    tags: ['focus', 'morning-routine', 'clarity'],
    isFavorite: true,
    location: 'Home Studio',
    wordCount: 138,
    readingTime: 1,
  },
  {
    id: 'entry-2',
    title: 'The Art of Savoring Small Milestones',
    content: `We wrapped up a long sprint at work today. Usually, our default reaction as a team is to immediately pivot to the next queue of challenges without pausing to celebrate what we just built.

Today I made a conscious effort to acknowledge the effort:
- Thanked Elena for her thoughtful code reviews that caught subtle edge cases.
- Recorded the architectural lessons learned so we don't repeat old oversights.
- Treated myself to an evening chamomile tea and read thirty pages of my favorite book.

Gratitude isn't just a passive feeling; it's a deliberate practice of attention.`,
    date: '2026-09-11',
    time: '20:40',
    createdAt: new Date('2026-09-11T20:40:00').getTime(),
    updatedAt: new Date('2026-09-11T20:40:00').getTime(),
    mood: 'grateful',
    weather: 'partly-cloudy',
    tags: ['gratitude', 'work', 'mindfulness'],
    isFavorite: true,
    location: 'Study',
    wordCount: 104,
    readingTime: 1,
  },
  {
    id: 'entry-3',
    title: 'Reflections on Pace and Rest',
    content: `Midweek exhaustion started creeping in around mid-afternoon. Instead of pushing through with a third cup of coffee, I closed my laptop and did a 10-minute breathwork exercise.

It's fascinating how our culture idolizes relentless output while treating recovery as an afterthought. You cannot pour from an empty vessel.

### Intentions for the weekend:
1. Disconnect digital notifications for at least 24 hours.
2. Cook a nourishing slow-simmered vegetable soup from scratch.
3. Finish the hand-drawn sketch of the neighborhood park.`,
    date: '2026-09-09',
    time: '18:20',
    createdAt: new Date('2026-09-09T18:20:00').getTime(),
    updatedAt: new Date('2026-09-09T18:20:00').getTime(),
    mood: 'calm',
    weather: 'cloudy',
    tags: ['wellbeing', 'rest', 'habits'],
    isFavorite: false,
    location: 'Terrace',
    wordCount: 92,
    readingTime: 1,
  },
];
