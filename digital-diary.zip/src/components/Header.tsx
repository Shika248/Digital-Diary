import React from 'react';
import { 
  BookOpen, 
  Calendar as CalendarIcon, 
  BarChart3, 
  Plus, 
  Lock, 
  Settings as SettingsIcon, 
  Flame, 
  Download 
} from 'lucide-react';
import { ViewMode, DiarySettings } from '../types';

interface HeaderProps {
  currentView: ViewMode;
  onViewChange: (view: ViewMode) => void;
  onNewEntry: () => void;
  onLock: () => void;
  onOpenSettings: () => void;
  onQuickExport: () => void;
  streak: { current: number; longest: number };
  settings: DiarySettings;
  entriesCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  onViewChange,
  onNewEntry,
  onLock,
  onOpenSettings,
  onQuickExport,
  streak,
  settings,
  entriesCount,
}) => {
  const todayFormatted = new Date().toLocaleDateString(undefined, {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });

  return (
    <header className="sticky top-0 z-30 bg-stone-50/90 backdrop-blur-md border-b border-stone-200/80 transition-colors">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-18 flex items-center justify-between gap-4">
        {/* Brand & Date */}
        <div className="flex items-center gap-4 min-w-0">
          <button
            id="brand-home-btn"
            onClick={() => onViewChange('timeline')}
            className="flex items-center gap-2.5 text-left group transition-transform focus:outline-none"
            title="Go to journal timeline"
          >
            <div className="w-10 h-10 rounded-xl bg-stone-900 text-stone-100 flex items-center justify-center shadow-xs group-hover:bg-amber-900 transition-colors">
              <BookOpen className="w-5 h-5" />
            </div>
            <div className="truncate">
              <h1 className="font-serif font-semibold text-lg sm:text-xl text-stone-900 tracking-tight leading-none group-hover:text-amber-950">
                {settings.authorName ? `${settings.authorName}'s Diary` : 'Digital Diary'}
              </h1>
              <p className="text-xs text-stone-500 mt-1 font-sans hidden sm:block">
                {todayFormatted}
              </p>
            </div>
          </button>

          {/* Streak Counter Pill */}
          <div 
            id="streak-indicator"
            className="hidden md:flex items-center gap-1.5 px-3 py-1 bg-amber-100/60 border border-amber-300/60 text-amber-900 rounded-full text-xs font-medium"
            title={`Current writing streak: ${streak.current} days | Longest: ${streak.longest} days`}
          >
            <Flame className={`w-3.5 h-3.5 ${streak.current > 0 ? 'text-amber-600 fill-amber-500' : 'text-stone-400'}`} />
            <span>{streak.current} {streak.current === 1 ? 'day streak' : 'days streak'}</span>
          </div>
        </div>

        {/* Center View Selector Tabs */}
        <nav className="flex items-center p-1 bg-stone-200/70 rounded-xl">
          <button
            id="nav-timeline-tab"
            onClick={() => onViewChange('timeline')}
            className={`flex items-center gap-1.5 px-3 sm:px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-all ${
              currentView === 'timeline'
                ? 'bg-white text-stone-900 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span className="hidden sm:inline">Timeline</span>
            <span className="text-xs px-1.5 py-0.2 bg-stone-100 text-stone-600 rounded-full hidden md:inline">
              {entriesCount}
            </span>
          </button>

          <button
            id="nav-calendar-tab"
            onClick={() => onViewChange('calendar')}
            className={`flex items-center gap-1.5 px-3 sm:px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-all ${
              currentView === 'calendar'
                ? 'bg-white text-stone-900 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <CalendarIcon className="w-4 h-4" />
            <span className="hidden sm:inline">Calendar</span>
          </button>

          <button
            id="nav-insights-tab"
            onClick={() => onViewChange('insights')}
            className={`flex items-center gap-1.5 px-3 sm:px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-all ${
              currentView === 'insights'
                ? 'bg-white text-stone-900 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span className="hidden sm:inline">Insights</span>
          </button>
        </nav>

        {/* Right Actions */}
        <div className="flex items-center gap-2">
          {/* Quick Export Button */}
          <button
            id="btn-quick-export"
            onClick={onQuickExport}
            title="Download journal as Markdown"
            className="hidden lg:flex items-center justify-center w-9 h-9 text-stone-600 hover:text-stone-900 hover:bg-stone-200/60 rounded-xl transition-colors"
          >
            <Download className="w-4 h-4" />
          </button>

          {/* Settings Button */}
          <button
            id="btn-open-settings"
            onClick={onOpenSettings}
            title="Settings & Privacy"
            className="flex items-center justify-center w-9 h-9 text-stone-600 hover:text-stone-900 hover:bg-stone-200/60 rounded-xl transition-colors"
          >
            <SettingsIcon className="w-4 h-4" />
          </button>

          {/* Lock Button (if PIN set) */}
          {settings.hasPin && (
            <button
              id="btn-lock-diary"
              onClick={onLock}
              title="Lock diary now"
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-stone-700 bg-stone-200/80 hover:bg-stone-300/80 rounded-xl text-xs font-medium transition-colors"
            >
              <Lock className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Lock</span>
            </button>
          )}

          {/* New Entry Primary CTA */}
          <button
            id="btn-header-new-entry"
            onClick={onNewEntry}
            className="flex items-center gap-2 px-3.5 py-2 bg-stone-900 hover:bg-stone-800 text-stone-100 rounded-xl text-xs sm:text-sm font-medium shadow-xs transition-colors focus:ring-2 focus:ring-stone-400 focus:outline-none"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden xs:inline">New Entry</span>
          </button>
        </div>
      </div>
    </header>
  );
};
