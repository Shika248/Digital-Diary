import React, { useState } from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Plus, 
  Calendar as CalendarIcon, 
  BookOpen, 
  Eye, 
  Edit3 
} from 'lucide-react';
import { DiaryEntry } from '../types';
import { MOODS } from '../utils/moods';

interface CalendarViewProps {
  entries: DiaryEntry[];
  onSelectEntry: (entry: DiaryEntry) => void;
  onEditEntry: (entry: DiaryEntry) => void;
  onCreateForDate: (dateStr: string) => void;
}

export const CalendarView: React.FC<CalendarViewProps> = ({
  entries,
  onSelectEntry,
  onEditEntry,
  onCreateForDate,
}) => {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );

  const year = currentMonth.getFullYear();
  const month = currentMonth.getMonth();

  // Month navigation
  const prevMonth = () => {
    setCurrentMonth(new Date(year, month - 1, 1));
  };

  const nextMonth = () => {
    setCurrentMonth(new Date(year, month + 1, 1));
  };

  const jumpToday = () => {
    const today = new Date();
    setCurrentMonth(today);
    setSelectedDate(today.toISOString().split('T')[0]);
  };

  // Map entries by date for fast lookup
  const entriesByDate: Record<string, DiaryEntry[]> = {};
  entries.forEach((e) => {
    if (!entriesByDate[e.date]) {
      entriesByDate[e.date] = [];
    }
    entriesByDate[e.date].push(e);
  });

  // Calculate calendar grid days
  const firstDayOfMonth = new Date(year, month, 1);
  const lastDayOfMonth = new Date(year, month + 1, 0);
  const totalDays = lastDayOfMonth.getDate();

  // Day of week index (0=Sunday, 1=Monday, etc.). Let's start with Sunday
  const startDayIndex = firstDayOfMonth.getDay();

  // Days from previous month to fill the first row
  const prevMonthLastDay = new Date(year, month, 0).getDate();
  const calendarCells: { dateStr: string; dayNum: number; isCurrentMonth: boolean }[] = [];

  for (let i = startDayIndex - 1; i >= 0; i--) {
    const prevDayNum = prevMonthLastDay - i;
    const d = new Date(year, month - 1, prevDayNum);
    calendarCells.push({
      dateStr: d.toISOString().split('T')[0],
      dayNum: prevDayNum,
      isCurrentMonth: false,
    });
  }

  // Days of current month
  for (let d = 1; d <= totalDays; d++) {
    const dateObj = new Date(year, month, d);
    // Format YYYY-MM-DD
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    calendarCells.push({
      dateStr,
      dayNum: d,
      isCurrentMonth: true,
    });
  }

  // Fill remaining days of the last week
  const remainingCells = 42 - calendarCells.length; // 6 rows * 7 days
  if (remainingCells > 0 && remainingCells < 7) {
    for (let d = 1; d <= remainingCells; d++) {
      const nextDate = new Date(year, month + 1, d);
      calendarCells.push({
        dateStr: nextDate.toISOString().split('T')[0],
        dayNum: d,
        isCurrentMonth: false,
      });
    }
  }

  const todayStr = new Date().toISOString().split('T')[0];
  const selectedEntries = entriesByDate[selectedDate] || [];

  // Count active days in this month
  const activeDaysThisMonth = Object.keys(entriesByDate).filter((dStr) => {
    const d = new Date(dStr);
    return d.getFullYear() === year && d.getMonth() === month;
  }).length;

  const formattedSelectedDate = new Date(`${selectedDate}T12:00:00`).toLocaleDateString(
    undefined,
    {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
      year: 'numeric',
    }
  );

  return (
    <div id="calendar-container" className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
      {/* Calendar Header Card */}
      <div className="bg-white rounded-2xl border border-stone-200/80 p-5 sm:p-6 shadow-xs mb-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="font-serif font-bold text-xl sm:text-2xl text-stone-900 tracking-tight">
              {currentMonth.toLocaleDateString(undefined, { month: 'long', year: 'numeric' })}
            </h2>
            <p className="text-xs text-stone-500 mt-0.5">
              {activeDaysThisMonth} {activeDaysThisMonth === 1 ? 'day recorded' : 'days recorded'} this month
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={jumpToday}
              className="px-3 py-1.5 text-xs font-medium text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-xl transition-colors"
            >
              Today
            </button>
            <div className="flex items-center gap-1 border border-stone-200 rounded-xl p-0.5">
              <button
                onClick={prevMonth}
                className="p-1.5 text-stone-600 hover:text-stone-900 hover:bg-stone-100 rounded-lg transition-colors"
                title="Previous month"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={nextMonth}
                className="p-1.5 text-stone-600 hover:text-stone-900 hover:bg-stone-100 rounded-lg transition-colors"
                title="Next month"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Days of week header */}
        <div className="grid grid-cols-7 gap-1 text-center mb-2">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
            <div key={day} className="text-xs font-semibold text-stone-400 py-1">
              {day}
            </div>
          ))}
        </div>

        {/* Calendar Grid */}
        <div className="grid grid-cols-7 gap-1 sm:gap-2">
          {calendarCells.map((cell, idx) => {
            const isToday = cell.dateStr === todayStr;
            const isSelected = cell.dateStr === selectedDate;
            const dayEntries = entriesByDate[cell.dateStr] || [];
            const hasEntries = dayEntries.length > 0;

            return (
              <button
                key={idx}
                onClick={() => setSelectedDate(cell.dateStr)}
                className={`min-h-16 sm:min-h-20 p-1.5 sm:p-2 rounded-xl border flex flex-col justify-between text-left transition-all ${
                  isSelected
                    ? 'border-stone-900 bg-stone-50 ring-1 ring-stone-900'
                    : isToday
                    ? 'border-amber-300 bg-amber-50/40'
                    : cell.isCurrentMonth
                    ? 'border-stone-100 bg-stone-50/50 hover:bg-stone-100/70 hover:border-stone-200'
                    : 'border-transparent bg-stone-50/20 text-stone-300 hover:bg-stone-50/40'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span
                    className={`text-xs font-medium w-5 h-5 flex items-center justify-center rounded-full ${
                      isToday
                        ? 'bg-amber-600 text-white font-bold'
                        : isSelected
                        ? 'bg-stone-900 text-white'
                        : cell.isCurrentMonth
                        ? 'text-stone-800'
                        : 'text-stone-400'
                    }`}
                  >
                    {cell.dayNum}
                  </span>

                  {dayEntries.length > 1 && (
                    <span className="text-[10px] font-semibold px-1 bg-stone-200 text-stone-700 rounded-full">
                      {dayEntries.length}
                    </span>
                  )}
                </div>

                {/* Mood dots for entries on this day */}
                {hasEntries && (
                  <div className="flex items-center gap-1 mt-1 overflow-hidden">
                    {dayEntries.slice(0, 3).map((e) => {
                      const moodConf = MOODS[e.mood] || MOODS.calm;
                      return (
                        <span
                          key={e.id}
                          className="w-2 h-2 rounded-full shrink-0"
                          style={{ backgroundColor: moodConf.dotColor }}
                          title={`${moodConf.label}: ${e.title}`}
                        />
                      );
                    })}
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Day Details Panel */}
      <div className="bg-white rounded-2xl border border-stone-200/80 p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-stone-100 mb-4">
          <div>
            <h3 className="font-serif font-bold text-lg text-stone-900">
              {formattedSelectedDate}
            </h3>
            <p className="text-xs text-stone-500">
              {selectedEntries.length} {selectedEntries.length === 1 ? 'entry' : 'entries'} on this date
            </p>
          </div>

          <button
            onClick={() => onCreateForDate(selectedDate)}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-stone-900 hover:bg-stone-800 text-stone-100 rounded-xl text-xs sm:text-sm font-medium transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Write for this day</span>
          </button>
        </div>

        {selectedEntries.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-stone-400 text-xs sm:text-sm mb-4">
              No entries recorded on this day.
            </p>
            <button
              onClick={() => onCreateForDate(selectedDate)}
              className="text-amber-800 hover:text-amber-950 text-xs font-semibold underline"
            >
              Capture a thought or memory for this date
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {selectedEntries.map((entry) => {
              const mood = MOODS[entry.mood] || MOODS.calm;
              return (
                <div
                  key={entry.id}
                  className="p-4 rounded-xl border border-stone-100 bg-stone-50/60 hover:bg-stone-100/70 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-stone-400 font-medium">{entry.time}</span>
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium border ${mood.bgClass} ${mood.textClass} ${mood.borderClass}`}
                      >
                        <span>{mood.emoji}</span>
                        <span>{mood.label}</span>
                      </span>
                    </div>
                    <h4 className="font-serif font-semibold text-stone-900 text-base">
                      {entry.title || 'Untitled Entry'}
                    </h4>
                    <p className="text-xs text-stone-600 line-clamp-1">
                      {entry.content.replace(/[#*`_>]/g, '')}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-center">
                    <button
                      onClick={() => onSelectEntry(entry)}
                      className="flex items-center gap-1 px-3 py-1.5 bg-white border border-stone-200 hover:border-stone-300 rounded-lg text-xs font-medium text-stone-700 shadow-2xs transition-colors"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Read</span>
                    </button>
                    <button
                      onClick={() => onEditEntry(entry)}
                      className="p-1.5 text-stone-500 hover:text-stone-900 rounded-lg hover:bg-stone-200/60 transition-colors"
                      title="Edit"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
