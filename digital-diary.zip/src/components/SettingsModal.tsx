import React, { useState, useRef } from 'react';
import { 
  X, 
  Lock, 
  Unlock, 
  ShieldCheck, 
  User, 
  Download, 
  Upload, 
  RefreshCw, 
  FileText, 
  Check, 
  AlertTriangle 
} from 'lucide-react';
import { DiarySettings, DiaryEntry } from '../types';
import { exportEntriesAsJSON, exportEntriesAsMarkdown } from '../utils/storage';
import { INITIAL_ENTRIES } from '../data/initialEntries';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: DiarySettings;
  entries: DiaryEntry[];
  onUpdateSettings: (settings: DiarySettings) => void;
  onRestoreEntries: (entries: DiaryEntry[]) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  entries,
  onUpdateSettings,
  onRestoreEntries,
}) => {
  if (!isOpen) return null;

  const [authorName, setAuthorName] = useState(settings.authorName);
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [pinError, setPinError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [showPinSetup, setShowPinSetup] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSaveAuthor = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings({ ...settings, authorName: authorName.trim() });
    showSuccess('Author name updated.');
  };

  const handleSetPin = (e: React.FormEvent) => {
    e.preventDefault();
    setPinError('');

    if (!/^\d{4}$/.test(newPin)) {
      setPinError('PIN must be exactly 4 numeric digits.');
      return;
    }

    if (newPin !== confirmPin) {
      setPinError('PIN confirmation does not match.');
      return;
    }

    onUpdateSettings({
      ...settings,
      pin: newPin,
      hasPin: true,
    });
    setNewPin('');
    setConfirmPin('');
    setShowPinSetup(false);
    showSuccess('Security PIN enabled.');
  };

  const handleRemovePin = () => {
    if (confirm('Are you sure you want to remove passcode protection?')) {
      onUpdateSettings({
        ...settings,
        pin: null,
        hasPin: false,
      });
      showSuccess('Security PIN removed.');
    }
  };

  const showSuccess = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(''), 3000);
  };

  // Import JSON backup
  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const parsed = JSON.parse(text);
        const importedEntries: DiaryEntry[] = Array.isArray(parsed)
          ? parsed
          : Array.isArray(parsed.entries)
          ? parsed.entries
          : [];

        if (importedEntries.length === 0) {
          alert('Could not find any valid diary entries in this file.');
          return;
        }

        if (
          confirm(
            `Found ${importedEntries.length} entries in backup. Would you like to merge them with your current journal?`
          )
        ) {
          // Merge by unique ID
          const existingIds = new Set(entries.map((e) => e.id));
          const merged = [...entries];
          importedEntries.forEach((ie) => {
            if (!existingIds.has(ie.id)) {
              merged.push(ie);
              existingIds.add(ie.id);
            }
          });
          onRestoreEntries(merged);
          showSuccess(`Successfully merged ${importedEntries.length} entries.`);
        }
      } catch (err) {
        console.error('Import error:', err);
        alert('Invalid JSON file format.');
      }
    };
    reader.readAsText(file);
    if (e.target) e.target.value = '';
  };

  const handleResetSample = () => {
    if (
      confirm(
        'Reset your journal to initial sample entries? This will replace your current entries with the default samples.'
      )
    ) {
      onRestoreEntries(INITIAL_ENTRIES);
      showSuccess('Restored sample memories.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div 
        id="settings-modal-card" 
        className="w-full max-w-lg bg-white rounded-2xl shadow-xl border border-stone-200 overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-200/80 bg-stone-50/70">
          <div>
            <h3 className="font-serif font-bold text-lg text-stone-900">Settings & Privacy</h3>
            <p className="text-xs text-stone-500">Personalization, passcode lock, and data backups</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-700 hover:bg-stone-200/60 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Feedback alert if any */}
        {successMsg && (
          <div className="mx-6 mt-4 p-2.5 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-medium rounded-xl flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-600" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Settings Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Author Name Section */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-stone-800 font-serif font-semibold text-base">
              <User className="w-4 h-4 text-stone-500" />
              <span>Diary Title & Author</span>
            </div>
            <form onSubmit={handleSaveAuthor} className="flex gap-2">
              <input
                type="text"
                placeholder="Enter your name..."
                value={authorName}
                onChange={(e) => setAuthorName(e.target.value)}
                className="flex-1 px-3.5 py-2 text-xs sm:text-sm bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-stone-400 focus:bg-white"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs sm:text-sm font-medium transition-colors"
              >
                Save
              </button>
            </form>
          </div>

          <hr className="border-stone-100" />

          {/* Passcode / PIN Security Section */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-stone-800 font-serif font-semibold text-base">
                <Lock className="w-4 h-4 text-stone-500" />
                <span>Passcode Lock</span>
              </div>
              <span
                className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                  settings.hasPin
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                    : 'bg-stone-100 text-stone-600'
                }`}
              >
                {settings.hasPin ? 'PIN Enabled' : 'No PIN Set'}
              </span>
            </div>
            <p className="text-xs text-stone-500">
              Lock your journal with a 4-digit code so no one nearby can read your reflections.
            </p>

            {settings.hasPin ? (
              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setShowPinSetup(!showPinSetup)}
                  className="px-3.5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-medium transition-colors"
                >
                  Change PIN
                </button>
                <button
                  type="button"
                  onClick={handleRemovePin}
                  className="px-3.5 py-2 text-rose-600 hover:bg-rose-50 rounded-xl text-xs font-medium transition-colors"
                >
                  Remove PIN
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setShowPinSetup(true)}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-medium transition-colors"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Create 4-digit Passcode</span>
              </button>
            )}

            {showPinSetup && (
              <form onSubmit={handleSetPin} className="p-4 bg-stone-50 border border-stone-200 rounded-xl space-y-3 mt-2">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-medium text-stone-600 mb-1">
                      New 4-digit PIN
                    </label>
                    <input
                      type="password"
                      maxLength={4}
                      placeholder="••••"
                      value={newPin}
                      onChange={(e) => setNewPin(e.target.value.replace(/\D/g, ''))}
                      className="w-full text-center tracking-widest text-lg font-mono py-1.5 bg-white border border-stone-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-stone-400"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-stone-600 mb-1">
                      Confirm PIN
                    </label>
                    <input
                      type="password"
                      maxLength={4}
                      placeholder="••••"
                      value={confirmPin}
                      onChange={(e) => setConfirmPin(e.target.value.replace(/\D/g, ''))}
                      className="w-full text-center tracking-widest text-lg font-mono py-1.5 bg-white border border-stone-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-stone-400"
                    />
                  </div>
                </div>

                {pinError && <p className="text-xs text-rose-600">{pinError}</p>}

                <div className="flex items-center justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setShowPinSetup(false)}
                    className="px-3 py-1.5 text-xs text-stone-600 hover:text-stone-900"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 bg-stone-900 text-white rounded-lg text-xs font-medium hover:bg-stone-800"
                  >
                    Set PIN
                  </button>
                </div>
              </form>
            )}
          </div>

          <hr className="border-stone-100" />

          {/* Data Portability & Backup */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-stone-800 font-serif font-semibold text-base">
              <Download className="w-4 h-4 text-stone-500" />
              <span>Export & Backup</span>
            </div>
            <p className="text-xs text-stone-500">
              Your diary belongs entirely to you. Download complete copies in open formats whenever you wish.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
              <button
                onClick={() => exportEntriesAsMarkdown(entries, settings.authorName)}
                className="flex items-center justify-center gap-2 px-3.5 py-2.5 border border-stone-200 bg-stone-50 hover:bg-stone-100 rounded-xl text-xs font-medium text-stone-800 transition-colors"
              >
                <FileText className="w-4 h-4 text-amber-700" />
                <span>Export as Markdown (.md)</span>
              </button>

              <button
                onClick={() => exportEntriesAsJSON(entries, settings.authorName)}
                className="flex items-center justify-center gap-2 px-3.5 py-2.5 border border-stone-200 bg-stone-50 hover:bg-stone-100 rounded-xl text-xs font-medium text-stone-800 transition-colors"
              >
                <Download className="w-4 h-4 text-emerald-700" />
                <span>Export Backup (.json)</span>
              </button>
            </div>

            {/* Import Backup */}
            <div className="pt-2">
              <input
                ref={fileInputRef}
                type="file"
                accept=".json"
                className="hidden"
                onChange={handleImportJSON}
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full flex items-center justify-center gap-2 px-3.5 py-2 border border-dashed border-stone-300 hover:border-stone-400 bg-stone-50/50 hover:bg-stone-100/50 rounded-xl text-xs font-medium text-stone-700 transition-colors"
              >
                <Upload className="w-4 h-4 text-stone-500" />
                <span>Restore or Merge from JSON Backup</span>
              </button>
            </div>
          </div>

          <hr className="border-stone-100" />

          {/* Privacy Note */}
          <div className="p-3.5 bg-amber-50/50 border border-amber-200/60 rounded-xl flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
            <div className="text-xs text-stone-600 leading-relaxed">
              <strong className="text-stone-800 font-medium block mb-0.5">Private & Offline-First</strong>
              All journal entries, photos, and moods are preserved locally in your browser’s storage. No ads, tracking, or cloud sharing.
            </div>
          </div>

          {/* Restore sample entries */}
          <div className="pt-2 text-right">
            <button
              onClick={handleResetSample}
              className="text-[11px] text-stone-400 hover:text-stone-700 underline"
            >
              Reset to default starter entries
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
