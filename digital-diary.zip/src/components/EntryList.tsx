import React, { useState } from 'react';
import { 
  Search, 
  Star, 
  Tag as TagIcon, 
  Filter, 
  Calendar as CalendarIcon, 
  ChevronRight, 
  Trash2, 
  Edit3, 
  Sparkles, 
  ArrowUpDown,
  BookOpen,
  Eye
} from 'lucide-react';
import { DiaryEntry, MoodType } from '../types';
import { MOODS } from '../utils/moods';

interface EntryListProps {
  entries: DiaryEntry[];
  onSelectEntry: (entry: DiaryEntry) => void;
  onEditEntry: (entry: DiaryEntry) => void;
  onDeleteEntry: (id: string) => void;
  onToggleFavorite: (id: string) => void;
  onNewEntry: () => void;
  onOpenPrompts: () => void;
}

export const EntryList: React.FC<EntryListProps> = ({
  entries,
  onSelectEntry,
  onEditEntry,
  onDeleteEntry,
  onToggleFavorite,
  onNewEntry,
  onOpenPrompts,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMood, setSelectedMood] = useState<MoodType | 'all'>('all');
  const [selectedTag, setSelectedTag] = useState<string | 'all'>('all');
  const [onlyFavorites, setOnlyFavorites] = useState(false);
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest'>('newest');

  // Extract all unique tags
  const allTags = Array.from(
    new Set(entries.flatMap((e) => e.tags || []))
  ).filter(Boolean);

  // Filter and Sort entries
  const filteredEntries = entries.filter((entry) => {
    // Search query match
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      const matchTitle = entry.title?.toLowerCase().includes(query);
      const matchContent = entry.content?.toLowerCase().includes(query);
      const matchTag = entry.tags?.some((t) => t.toLowerCase().includes(query));
      const matchLocation = entry.location?.toLowerCase().includes(query);
      if (!matchTitle && !matchContent && !matchTag && !matchLocation) {
        return false;
      }
    }

    // Mood match
    if (selectedMood !== 'all' && entry.mood !== selectedMood) {
      return false;
    }

    // Tag match
    if (selectedTag !== 'all' && (!entry.tags || !entry.tags.includes(selectedTag))) {
      return false;
    }

    // Favorites match
    if (onlyFavorites && !entry.isFavorite) {
      return false;
    }

    return true;
  });

  const sortedEntries = [...filteredEntries].sort((a, b) => {
    const timeA = new Date(`${a.date}T${a.time || '00:00'}`).getTime();
    const timeB = new Date(`${b.date}T${b.time || '00:00'}`).getTime();
    return sortOrder === 'newest' ? timeB - timeA : timeA - timeB;
  });

  const hasActiveFilters =
    searchQuery.trim() !== '' ||
    selectedMood !== 'all' ||
    selectedTag !== 'all' ||
    onlyFavorites;

  const resetFilters = () => {
    setSearchQuery('');
    setSelectedMood('all');
    setSelectedTag('all');
    setOnlyFavorites(false);
  };

  return (
    <div id="timeline-container" className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
      {/* Top Search & Filter Bar */}
      <div className="bg-white rounded-2xl border border-stone-200/80 p-4 shadow-xs mb-8 space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              id="search-input"
              type="text"
              placeholder="Search memories, thoughts, tags, places..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-stone-400 focus:bg-white transition-all"
            />
          </div>

          {/* Quick Filter Buttons */}
          <div className="flex items-center gap-2">
            <button
              id="filter-favorites-btn"
              onClick={() => setOnlyFavorites(!onlyFavorites)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs sm:text-sm font-medium border transition-colors ${
                onlyFavorites
                  ? 'bg-amber-50 border-amber-300 text-amber-900'
                  : 'bg-stone-50 border-stone-200 text-stone-700 hover:bg-stone-100'
              }`}
            >
              <Star className={`w-4 h-4 ${onlyFavorites ? 'fill-amber-500 text-amber-500' : 'text-stone-400'}`} />
              <span className="hidden xs:inline">Starred</span>
            </button>

            <button
              id="sort-order-btn"
              onClick={() => setSortOrder(sortOrder === 'newest' ? 'oldest' : 'newest')}
              className="flex items-center gap-1.5 px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm font-medium text-stone-700 hover:bg-stone-100 transition-colors"
              title={`Sorting: ${sortOrder === 'newest' ? 'Newest first' : 'Oldest first'}`}
            >
              <ArrowUpDown className="w-4 h-4 text-stone-400" />
              <span className="hidden xs:inline capitalize">{sortOrder}</span>
            </button>
          </div>
        </div>

        {/* Mood Filter Pill Carousel */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 pt-1 no-scrollbar">
          <span className="text-xs text-stone-400 font-medium whitespace-nowrap pl-1">Mood:</span>
          
          <button
            onClick={() => setSelectedMood('all')}
            className={`px-2.5 py-1 rounded-full text-xs font-medium whitespace-nowrap border transition-colors ${
              selectedMood === 'all'
                ? 'bg-stone-900 text-white border-stone-900'
                : 'bg-stone-100 text-stone-600 border-stone-200 hover:bg-stone-200/70'
            }`}
          >
            All Moods
          </button>

          {(Object.keys(MOODS) as MoodType[]).map((moodKey) => {
            const mood = MOODS[moodKey];
            const isSelected = selectedMood === moodKey;
            return (
              <button
                key={moodKey}
                onClick={() => setSelectedMood(isSelected ? 'all' : moodKey)}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium whitespace-nowrap border transition-colors ${
                  isSelected
                    ? `${mood.bgClass} ${mood.textClass} ${mood.borderClass} font-semibold ring-1 ring-stone-400`
                    : 'bg-stone-50 text-stone-600 border-stone-200 hover:bg-stone-100'
                }`}
              >
                <span>{mood.emoji}</span>
                <span>{mood.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tag Filters Row if tags exist */}
        {allTags.length > 0 && (
          <div className="flex items-center gap-1.5 overflow-x-auto pt-1 no-scrollbar">
            <span className="text-xs text-stone-400 font-medium whitespace-nowrap pl-1">Tags:</span>
            <button
              onClick={() => setSelectedTag('all')}
              className={`px-2 py-0.5 rounded-md text-xs font-medium whitespace-nowrap ${
                selectedTag === 'all' ? 'text-stone-900 font-bold' : 'text-stone-500 hover:text-stone-800'
              }`}
            >
              All
            </button>
            {allTags.map((tag) => (
              <button
                key={tag}
                onClick={() => setSelectedTag(selectedTag === tag ? 'all' : tag)}
                className={`px-2 py-0.5 rounded-md text-xs font-medium whitespace-nowrap transition-colors ${
                  selectedTag === tag
                    ? 'bg-amber-100 text-amber-900 font-semibold'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200/80'
                }`}
              >
                #{tag}
              </button>
            ))}
          </div>
        )}

        {/* Filter Reset Button if active */}
        {hasActiveFilters && (
          <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-xs text-stone-500">
            <span>Showing {sortedEntries.length} of {entries.length} memories</span>
            <button
              onClick={resetFilters}
              className="text-amber-800 hover:text-amber-950 font-medium underline"
            >
              Reset all filters
            </button>
          </div>
        )}
      </div>

      {/* Entries List */}
      {sortedEntries.length === 0 ? (
        <div className="text-center py-16 px-4 bg-white rounded-2xl border border-stone-200/80">
          <div className="w-12 h-12 rounded-full bg-stone-100 flex items-center justify-center mx-auto mb-4 text-stone-400">
            <BookOpen className="w-6 h-6" />
          </div>
          <h3 className="font-serif font-semibold text-lg text-stone-800 mb-1">
            {hasActiveFilters ? 'No matching memories found' : 'Your journal is waiting'}
          </h3>
          <p className="text-xs sm:text-sm text-stone-500 max-w-md mx-auto mb-6">
            {hasActiveFilters
              ? 'Try relaxing your search terms or clearing your filters to see past entries.'
              : 'Every day holds a story worth capturing. Take a quiet breath and pen down your very first reflection.'}
          </p>
          <div className="flex items-center justify-center gap-3">
            {hasActiveFilters ? (
              <button
                onClick={resetFilters}
                className="px-4 py-2 text-xs sm:text-sm font-medium text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-xl transition-colors"
              >
                Clear Filters
              </button>
            ) : (
              <>
                <button
                  onClick={onNewEntry}
                  className="px-4 py-2 text-xs sm:text-sm font-medium text-white bg-stone-900 hover:bg-stone-800 rounded-xl shadow-xs transition-colors"
                >
                  Write Your First Entry
                </button>
                <button
                  onClick={onOpenPrompts}
                  className="flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-medium text-amber-900 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-xl transition-colors"
                >
                  <Sparkles className="w-4 h-4 text-amber-600" />
                  <span>Explore Prompts</span>
                </button>
              </>
            )}
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          {sortedEntries.map((entry) => {
            const mood = MOODS[entry.mood] || MOODS.calm;
            const dateObj = new Date(`${entry.date}T${entry.time || '12:00'}`);
            const formattedDate = dateObj.toLocaleDateString(undefined, {
              weekday: 'short',
              month: 'short',
              day: 'numeric',
              year: 'numeric',
            });

            // Extract pure text preview from markdown/text
            const textPreview = entry.content
              .replace(/#+\s/g, '')
              .replace(/\*\*|[*_>]/g, '')
              .replace(/-\s(\[[ x]\]\s)?/g, '')
              .trim();

            return (
              <article
                key={entry.id}
                id={`entry-card-${entry.id}`}
                className="group relative bg-white hover:bg-stone-50/80 rounded-2xl border border-stone-200/90 p-5 sm:p-6 shadow-xs transition-all duration-200 hover:border-stone-300"
              >
                <div className="flex items-start justify-between gap-4 mb-3">
                  {/* Date & Mood Header */}
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider flex items-center gap-1">
                      <CalendarIcon className="w-3.5 h-3.5 text-stone-400" />
                      {formattedDate}
                    </span>
                    <span className="text-stone-300">·</span>
                    <span className="text-xs text-stone-400">{entry.time}</span>

                    {/* Mood Badge */}
                    <span
                      className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium border ${mood.bgClass} ${mood.textClass} ${mood.borderClass}`}
                    >
                      <span>{mood.emoji}</span>
                      <span>{mood.label}</span>
                    </span>

                    {/* Location Badge if present */}
                    {entry.location && (
                      <span className="text-xs text-stone-400 hidden sm:inline">
                        📍 {entry.location}
                      </span>
                    )}
                  </div>

                  {/* Actions: Favorite Star & More */}
                  <div className="flex items-center gap-1">
                    <button
                      id={`entry-star-btn-${entry.id}`}
                      onClick={() => onToggleFavorite(entry.id)}
                      title={entry.isFavorite ? 'Remove from favorites' : 'Mark as favorite'}
                      className="p-1.5 text-stone-400 hover:text-amber-500 rounded-lg hover:bg-stone-100 transition-colors"
                    >
                      <Star
                        className={`w-4 h-4 ${
                          entry.isFavorite ? 'fill-amber-500 text-amber-500' : ''
                        }`}
                      />
                    </button>

                    <button
                      id={`entry-edit-btn-${entry.id}`}
                      onClick={() => onEditEntry(entry)}
                      title="Edit entry"
                      className="p-1.5 text-stone-400 hover:text-stone-700 rounded-lg hover:bg-stone-100 transition-colors"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>

                    <button
                      id={`entry-delete-btn-${entry.id}`}
                      onClick={() => {
                        if (confirm('Are you sure you want to delete this memory?')) {
                          onDeleteEntry(entry.id);
                        }
                      }}
                      title="Delete entry"
                      className="p-1.5 text-stone-400 hover:text-rose-600 rounded-lg hover:bg-stone-100 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Entry Title & Snippet (Clickable to open Reader) */}
                <div
                  onClick={() => onSelectEntry(entry)}
                  className="cursor-pointer space-y-2"
                >
                  <h2 className="font-serif font-semibold text-lg sm:text-xl text-stone-900 group-hover:text-amber-950 transition-colors tracking-tight">
                    {entry.title || 'Untitled Entry'}
                  </h2>

                  <p className="font-sans text-xs sm:text-sm text-stone-600 line-clamp-3 leading-relaxed">
                    {textPreview || 'No written content in this entry.'}
                  </p>
                </div>

                {/* Attached Photo Thumbnails */}
                {entry.images && entry.images.length > 0 && (
                  <div className="flex items-center gap-2 mt-4 overflow-x-auto pb-1 no-scrollbar">
                    {entry.images.map((img, i) => (
                      <div
                        key={i}
                        onClick={() => onSelectEntry(entry)}
                        className="w-16 h-16 rounded-lg overflow-hidden border border-stone-200 shrink-0 cursor-pointer hover:opacity-90 transition-opacity"
                      >
                        <img
                          src={img}
                          alt="Attached memory preview"
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ))}
                  </div>
                )}

                {/* Footer: Tags & Reading Stats */}
                <div className="mt-4 pt-3 border-t border-stone-100 flex flex-wrap items-center justify-between gap-2 text-xs text-stone-500">
                  <div className="flex flex-wrap items-center gap-1.5">
                    {entry.tags && entry.tags.length > 0 ? (
                      entry.tags.map((tag) => (
                        <span
                          key={tag}
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedTag(tag);
                          }}
                          className="px-2 py-0.5 rounded-md bg-stone-100 hover:bg-amber-100 hover:text-amber-900 text-stone-600 font-medium cursor-pointer transition-colors"
                        >
                          #{tag}
                        </span>
                      ))
                    ) : (
                      <span className="text-stone-400">Untagged</span>
                    )}
                  </div>

                  <div className="flex items-center gap-3">
                    <span>{entry.wordCount || 0} words</span>
                    <span>·</span>
                    <button
                      onClick={() => onSelectEntry(entry)}
                      className="inline-flex items-center gap-1 font-medium text-stone-700 hover:text-stone-950 group/btn"
                    >
                      <span>Read</span>
                      <ChevronRight className="w-3.5 h-3.5 group-hover/btn:translate-x-0.5 transition-transform" />
                    </button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
};
