import React, { useState, useEffect, useRef } from 'react';
import { 
  ArrowLeft, 
  Save, 
  Calendar as CalendarIcon, 
  Clock, 
  MapPin, 
  Sparkles, 
  Mic, 
  MicOff, 
  Image as ImageIcon, 
  Bold, 
  Italic, 
  Heading1, 
  Heading2, 
  Quote, 
  List, 
  CheckSquare, 
  Minus, 
  Maximize2, 
  Minimize2, 
  Trash2, 
  Tag as TagIcon,
  X,
  Smile,
  Sun,
  Cloud,
  CloudRain,
  CloudSun,
  Wind,
  Snowflake
} from 'lucide-react';
import { DiaryEntry, MoodType, WeatherType } from '../types';
import { MOODS, WEATHERS } from '../utils/moods';

interface EditorProps {
  entry: DiaryEntry | null;
  onSave: (entry: DiaryEntry) => void;
  onDelete?: (id: string) => void;
  onCancel: () => void;
  onOpenPrompts: () => void;
  initialDate?: string;
}

export const Editor: React.FC<EditorProps> = ({
  entry,
  onSave,
  onDelete,
  onCancel,
  onOpenPrompts,
  initialDate,
}) => {
  const isEditing = Boolean(entry);

  const [title, setTitle] = useState(entry?.title || '');
  const [content, setContent] = useState(entry?.content || '');
  const [date, setDate] = useState(
    entry?.date || initialDate || new Date().toISOString().split('T')[0]
  );
  const [time, setTime] = useState(
    entry?.time ||
      new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
  );
  const [mood, setMood] = useState<MoodType>(entry?.mood || 'calm');
  const [weather, setWeather] = useState<WeatherType | undefined>(entry?.weather || 'sunny');
  const [location, setLocation] = useState(entry?.location || '');
  const [tags, setTags] = useState<string[]>(entry?.tags || []);
  const [tagInput, setTagInput] = useState('');
  const [images, setImages] = useState<string[]>(entry?.images || []);
  const [isFavorite, setIsFavorite] = useState(entry?.isFavorite || false);
  const [isFocusMode, setIsFocusMode] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [paperStyle, setPaperStyle] = useState<'classic' | 'warm' | 'slate' | 'midnight'>('classic');
  const [showMoodMenu, setShowMoodMenu] = useState(false);
  const [showWeatherMenu, setShowWeatherMenu] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'clean' | 'modified' | 'saved'>('clean');

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);

  // Auto calculate word count & reading time
  const words = content.trim() ? content.trim().split(/\s+/).length : 0;
  const readingTime = Math.max(1, Math.ceil(words / 200));

  // Speech recognition setup
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onresult = (event: any) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          if (event.results[i].isFinal) {
            transcript += event.results[i][0].transcript + ' ';
          }
        }
        if (transcript) {
          setContent((prev) => (prev ? prev + ' ' + transcript : transcript));
          setSaveStatus('modified');
        }
      };

      recognition.onerror = (e: any) => {
        console.error('Speech recognition error:', e);
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    }

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch {
          // ignore
        }
      }
    };
  }, []);

  const toggleListening = () => {
    if (!recognitionRef.current) {
      alert('Speech recognition is not supported in your browser. You can type directly.');
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      try {
        recognitionRef.current.start();
        setIsListening(true);
      } catch (err) {
        console.error('Failed to start speech recognition:', err);
      }
    }
  };

  // Formatting helpers
  const applyFormatting = (prefix: string, suffix: string = '') => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = content.substring(start, end);
    const beforeText = content.substring(0, start);
    const afterText = content.substring(end);

    let replacement = '';
    if (selectedText) {
      replacement = `${prefix}${selectedText}${suffix}`;
    } else {
      replacement = `${prefix}${suffix}`;
    }

    const newContent = beforeText + replacement + afterText;
    setContent(newContent);
    setSaveStatus('modified');

    setTimeout(() => {
      textarea.focus();
      const newCursorPos = start + prefix.length + selectedText.length;
      textarea.setSelectionRange(newCursorPos, newCursorPos);
    }, 10);
  };

  // Image Upload handler
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file: File) => {
      if (!file.type.startsWith('image/')) return;
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        if (result) {
          setImages((prev) => [...prev, result]);
          setSaveStatus('modified');
        }
      };
      reader.readAsDataURL(file);
    });

    if (e.target) e.target.value = '';
  };

  const removeImage = (indexToRemove: number) => {
    setImages((prev) => prev.filter((_, idx) => idx !== indexToRemove));
    setSaveStatus('modified');
  };

  // Tag management
  const handleAddTag = () => {
    const trimmed = tagInput.trim().replace(/^#/, '').toLowerCase();
    if (trimmed && !tags.includes(trimmed)) {
      setTags([...tags, trimmed]);
      setTagInput('');
      setSaveStatus('modified');
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter((t) => t !== tagToRemove));
    setSaveStatus('modified');
  };

  // Save handler
  const handleSave = () => {
    const finalTitle = title.trim() || (content.trim() ? content.trim().split('\n')[0].substring(0, 50) : 'Untitled Entry');
    const now = Date.now();

    const savedEntry: DiaryEntry = {
      id: entry?.id || `entry-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      title: finalTitle,
      content,
      date,
      time,
      createdAt: entry?.createdAt || now,
      updatedAt: now,
      mood,
      weather,
      tags,
      images,
      isFavorite,
      location: location.trim() || undefined,
      wordCount: words,
      readingTime,
    };

    onSave(savedEntry);
    setSaveStatus('saved');
  };

  // Paper style styling classes
  const getPaperClasses = () => {
    switch (paperStyle) {
      case 'warm':
        return 'bg-[#FAF6F0] text-stone-900 border-[#E8DFC8]';
      case 'slate':
        return 'bg-[#F1F5F9] text-slate-900 border-[#CBD5E1]';
      case 'midnight':
        return 'bg-[#1C1917] text-[#F5F5F4] border-[#292524]';
      default:
        return 'bg-white text-stone-900 border-stone-200';
    }
  };

  const isDarkPaper = paperStyle === 'midnight';

  const getWeatherIcon = (w?: WeatherType) => {
    switch (w) {
      case 'sunny':
        return <Sun className="w-4 h-4 text-amber-500" />;
      case 'partly-cloudy':
        return <CloudSun className="w-4 h-4 text-amber-400" />;
      case 'cloudy':
        return <Cloud className="w-4 h-4 text-stone-400" />;
      case 'rainy':
        return <CloudRain className="w-4 h-4 text-blue-400" />;
      case 'windy':
        return <Wind className="w-4 h-4 text-teal-400" />;
      case 'snowy':
        return <Snowflake className="w-4 h-4 text-sky-400" />;
      default:
        return <Sun className="w-4 h-4 text-amber-500" />;
    }
  };

  return (
    <div 
      id="editor-container" 
      className={`min-h-screen transition-colors ${
        isFocusMode 
          ? isDarkPaper ? 'bg-stone-950 p-4 sm:p-8' : 'bg-stone-100/70 p-4 sm:p-8' 
          : 'bg-stone-50 pb-24'
      }`}
    >
      <div className={`max-w-4xl mx-auto transition-all ${isFocusMode ? 'mt-0' : 'mt-4 px-4 sm:px-6'}`}>
        
        {/* Top Control Bar */}
        <div className="flex items-center justify-between gap-3 mb-4 py-2 border-b border-stone-200/80">
          <div className="flex items-center gap-2">
            <button
              id="editor-btn-back"
              onClick={onCancel}
              className="flex items-center gap-1.5 px-3 py-1.5 text-stone-600 hover:text-stone-900 hover:bg-stone-200/70 rounded-xl text-xs sm:text-sm font-medium transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>

            {/* Date & Time display */}
            <div className="flex items-center gap-2 text-xs text-stone-500 ml-2">
              <div className="flex items-center gap-1 bg-stone-100 px-2.5 py-1 rounded-lg border border-stone-200">
                <CalendarIcon className="w-3.5 h-3.5 text-stone-400" />
                <input
                  type="date"
                  value={date}
                  onChange={(e) => {
                    setDate(e.target.value);
                    setSaveStatus('modified');
                  }}
                  className="bg-transparent text-stone-800 font-medium focus:outline-none cursor-pointer"
                />
              </div>

              <div className="flex items-center gap-1 bg-stone-100 px-2.5 py-1 rounded-lg border border-stone-200">
                <Clock className="w-3.5 h-3.5 text-stone-400" />
                <input
                  type="time"
                  value={time}
                  onChange={(e) => {
                    setTime(e.target.value);
                    setSaveStatus('modified');
                  }}
                  className="bg-transparent text-stone-800 font-medium focus:outline-none cursor-pointer"
                />
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Focus Mode toggle */}
            <button
              id="editor-btn-focus"
              onClick={() => setIsFocusMode(!isFocusMode)}
              title={isFocusMode ? 'Exit focus mode' : 'Enter distraction-free focus mode'}
              className={`p-2 rounded-xl text-stone-600 hover:text-stone-900 transition-colors ${
                isFocusMode ? 'bg-amber-100 text-amber-900' : 'hover:bg-stone-200/70'
              }`}
            >
              {isFocusMode ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>

            {/* Prompts Drawer Button */}
            <button
              id="editor-btn-prompts"
              onClick={onOpenPrompts}
              className="flex items-center gap-1.5 px-3 py-1.5 text-amber-900 bg-amber-50 hover:bg-amber-100 border border-amber-200/80 rounded-xl text-xs sm:text-sm font-medium transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span className="hidden sm:inline">Inspiration</span>
            </button>

            {/* Delete button (if editing existing) */}
            {isEditing && onDelete && entry && (
              <button
                id="editor-btn-delete"
                onClick={() => {
                  if (confirm('Are you sure you want to delete this diary entry? This action cannot be undone.')) {
                    onDelete(entry.id);
                  }
                }}
                className="p-2 text-rose-600 hover:bg-rose-50 rounded-xl transition-colors"
                title="Delete entry"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}

            {/* Save Button */}
            <button
              id="editor-btn-save"
              onClick={handleSave}
              className="flex items-center gap-1.5 px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs sm:text-sm font-medium shadow-xs transition-colors"
            >
              <Save className="w-4 h-4" />
              <span>Save Entry</span>
            </button>
          </div>
        </div>

        {/* Paper Canvas */}
        <div 
          id="editor-canvas" 
          className={`rounded-2xl border shadow-xs transition-all overflow-hidden ${getPaperClasses()}`}
        >
          {/* Paper Header / Metadata Strip */}
          <div className={`px-6 sm:px-10 pt-8 pb-4 border-b flex flex-wrap items-center justify-between gap-4 ${
            isDarkPaper ? 'border-stone-800' : 'border-stone-100'
          }`}>
            <div className="flex flex-wrap items-center gap-3">
              {/* Mood Selector Dropdown */}
              <div className="relative">
                <button
                  id="editor-mood-selector-btn"
                  onClick={() => setShowMoodMenu(!showMoodMenu)}
                  className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium border transition-colors ${
                    isDarkPaper 
                      ? 'bg-stone-800 border-stone-700 text-stone-200' 
                      : `${MOODS[mood].bgClass} ${MOODS[mood].textClass} ${MOODS[mood].borderClass}`
                  }`}
                >
                  <span>{MOODS[mood].emoji}</span>
                  <span>{MOODS[mood].label}</span>
                </button>

                {showMoodMenu && (
                  <div className="absolute left-0 mt-2 z-20 w-44 bg-white rounded-xl shadow-lg border border-stone-200 py-1 grid grid-cols-1">
                    {(Object.keys(MOODS) as MoodType[]).map((m) => (
                      <button
                        key={m}
                        onClick={() => {
                          setMood(m);
                          setShowMoodMenu(false);
                          setSaveStatus('modified');
                        }}
                        className={`flex items-center gap-2 px-3 py-2 text-xs font-medium text-left hover:bg-stone-50 ${
                          mood === m ? 'bg-stone-100 font-semibold' : ''
                        }`}
                      >
                        <span>{MOODS[m].emoji}</span>
                        <span className="text-stone-800">{MOODS[m].label}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Weather Selector Dropdown */}
              <div className="relative">
                <button
                  id="editor-weather-selector-btn"
                  onClick={() => setShowWeatherMenu(!showWeatherMenu)}
                  className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium border transition-colors ${
                    isDarkPaper 
                      ? 'bg-stone-800 border-stone-700 text-stone-300' 
                      : 'bg-stone-100/80 border-stone-200 text-stone-700'
                  }`}
                >
                  {getWeatherIcon(weather)}
                  <span className="capitalize">{weather?.replace('-', ' ') || 'Weather'}</span>
                </button>

                {showWeatherMenu && (
                  <div className="absolute left-0 mt-2 z-20 w-40 bg-white rounded-xl shadow-lg border border-stone-200 py-1">
                    {WEATHERS.map((w) => (
                      <button
                        key={w.type}
                        onClick={() => {
                          setWeather(w.type);
                          setShowWeatherMenu(false);
                          setSaveStatus('modified');
                        }}
                        className={`w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-left hover:bg-stone-50 ${
                          weather === w.type ? 'bg-stone-100 font-semibold' : ''
                        }`}
                      >
                        {getWeatherIcon(w.type)}
                        <span className="text-stone-800">{w.label}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Location Input */}
              <div className="flex items-center gap-1 text-xs text-stone-500">
                <MapPin className="w-3.5 h-3.5 text-stone-400" />
                <input
                  type="text"
                  placeholder="Add location (e.g. Home, Cafe)..."
                  value={location}
                  onChange={(e) => {
                    setLocation(e.target.value);
                    setSaveStatus('modified');
                  }}
                  className={`bg-transparent placeholder:text-stone-400 focus:outline-none text-xs w-36 sm:w-48 ${
                    isDarkPaper ? 'text-stone-300' : 'text-stone-700'
                  }`}
                />
              </div>
            </div>

            {/* Paper Theme Picker */}
            <div className="flex items-center gap-1.5">
              <span className={`text-xs ${isDarkPaper ? 'text-stone-400' : 'text-stone-500'}`}>Theme:</span>
              <button
                type="button"
                onClick={() => setPaperStyle('classic')}
                title="Crisp White"
                className={`w-5 h-5 rounded-full bg-white border ${
                  paperStyle === 'classic' ? 'ring-2 ring-stone-900 border-stone-400' : 'border-stone-300'
                }`}
              />
              <button
                type="button"
                onClick={() => setPaperStyle('warm')}
                title="Warm Ivory"
                className={`w-5 h-5 rounded-full bg-[#FAF6F0] border ${
                  paperStyle === 'warm' ? 'ring-2 ring-stone-900 border-[#C8BFA8]' : 'border-stone-300'
                }`}
              />
              <button
                type="button"
                onClick={() => setPaperStyle('slate')}
                title="Slate"
                className={`w-5 h-5 rounded-full bg-[#F1F5F9] border ${
                  paperStyle === 'slate' ? 'ring-2 ring-stone-900 border-[#94A3B8]' : 'border-stone-300'
                }`}
              />
              <button
                type="button"
                onClick={() => setPaperStyle('midnight')}
                title="Midnight Noir"
                className={`w-5 h-5 rounded-full bg-[#1C1917] border ${
                  paperStyle === 'midnight' ? 'ring-2 ring-amber-400 border-stone-600' : 'border-stone-700'
                }`}
              />
            </div>
          </div>

          {/* Formatting & Voice Toolbar */}
          <div className={`px-6 sm:px-10 py-2 border-b flex flex-wrap items-center justify-between gap-2 ${
            isDarkPaper ? 'border-stone-800 bg-stone-900/40' : 'border-stone-100 bg-stone-50/50'
          }`}>
            <div className="flex flex-wrap items-center gap-1">
              <button
                type="button"
                onClick={() => applyFormatting('**', '**')}
                className={`p-1.5 rounded-lg text-xs font-semibold hover:bg-stone-200/60 transition-colors ${
                  isDarkPaper ? 'text-stone-300 hover:bg-stone-800' : 'text-stone-700'
                }`}
                title="Bold"
              >
                <Bold className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => applyFormatting('*', '*')}
                className={`p-1.5 rounded-lg text-xs hover:bg-stone-200/60 transition-colors ${
                  isDarkPaper ? 'text-stone-300 hover:bg-stone-800' : 'text-stone-700'
                }`}
                title="Italic"
              >
                <Italic className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => applyFormatting('### ')}
                className={`p-1.5 rounded-lg text-xs hover:bg-stone-200/60 transition-colors ${
                  isDarkPaper ? 'text-stone-300 hover:bg-stone-800' : 'text-stone-700'
                }`}
                title="Section Heading"
              >
                <Heading2 className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => applyFormatting('> ')}
                className={`p-1.5 rounded-lg text-xs hover:bg-stone-200/60 transition-colors ${
                  isDarkPaper ? 'text-stone-300 hover:bg-stone-800' : 'text-stone-700'
                }`}
                title="Quote"
              >
                <Quote className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => applyFormatting('- ')}
                className={`p-1.5 rounded-lg text-xs hover:bg-stone-200/60 transition-colors ${
                  isDarkPaper ? 'text-stone-300 hover:bg-stone-800' : 'text-stone-700'
                }`}
                title="Bullet List"
              >
                <List className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => applyFormatting('- [ ] ')}
                className={`p-1.5 rounded-lg text-xs hover:bg-stone-200/60 transition-colors ${
                  isDarkPaper ? 'text-stone-300 hover:bg-stone-800' : 'text-stone-700'
                }`}
                title="Checklist Item"
              >
                <CheckSquare className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => applyFormatting('\n---\n')}
                className={`p-1.5 rounded-lg text-xs hover:bg-stone-200/60 transition-colors ${
                  isDarkPaper ? 'text-stone-300 hover:bg-stone-800' : 'text-stone-700'
                }`}
                title="Horizontal Divider"
              >
                <Minus className="w-4 h-4" />
              </button>

              <div className="h-4 w-px bg-stone-300 mx-1" />

              {/* Photo Upload Button */}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                multiple
                className="hidden"
                onChange={handleImageUpload}
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className={`flex items-center gap-1 p-1.5 rounded-lg text-xs hover:bg-stone-200/60 transition-colors ${
                  isDarkPaper ? 'text-stone-300 hover:bg-stone-800' : 'text-stone-700'
                }`}
                title="Attach photo/memory"
              >
                <ImageIcon className="w-4 h-4 text-emerald-600" />
                <span className="hidden sm:inline">Add Photo</span>
              </button>

              {/* Speech-to-Text Dictation */}
              <button
                type="button"
                onClick={toggleListening}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                  isListening
                    ? 'bg-rose-500 text-white animate-pulse'
                    : isDarkPaper
                    ? 'text-stone-300 hover:bg-stone-800'
                    : 'text-stone-700 hover:bg-stone-200/60'
                }`}
                title="Voice dictation (speech-to-text)"
              >
                {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4 text-amber-600" />}
                <span>{isListening ? 'Listening...' : 'Dictate'}</span>
              </button>
            </div>

            {/* Word count & Reading time */}
            <div className={`text-xs ${isDarkPaper ? 'text-stone-400' : 'text-stone-500'}`}>
              <span>{words} words</span>
              <span className="mx-1.5">·</span>
              <span>{readingTime} min read</span>
            </div>
          </div>

          {/* Editor Body Canvas */}
          <div className="px-6 sm:px-12 py-8 space-y-6">
            {/* Title Input */}
            <input
              id="editor-title-input"
              type="text"
              placeholder="Title your entry..."
              value={title}
              onChange={(e) => {
                setTitle(e.target.value);
                setSaveStatus('modified');
              }}
              className={`w-full font-serif font-bold text-2xl sm:text-3xl lg:text-4xl bg-transparent placeholder:text-stone-300 focus:outline-none tracking-tight leading-snug ${
                isDarkPaper ? 'text-stone-100 placeholder:text-stone-600' : 'text-stone-900'
              }`}
            />

            {/* Tags Section */}
            <div className="flex flex-wrap items-center gap-2 pt-1 pb-2">
              <TagIcon className={`w-3.5 h-3.5 ${isDarkPaper ? 'text-stone-500' : 'text-stone-400'}`} />
              
              {tags.map((tag) => (
                <span
                  key={tag}
                  className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    isDarkPaper 
                      ? 'bg-stone-800 text-stone-300 border border-stone-700' 
                      : 'bg-stone-100 text-stone-700 border border-stone-200'
                  }`}
                >
                  #{tag}
                  <button
                    type="button"
                    onClick={() => handleRemoveTag(tag)}
                    className="hover:text-rose-500 transition-colors"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))}

              <div className="flex items-center">
                <input
                  type="text"
                  placeholder="Add tag + Enter..."
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ',') {
                      e.preventDefault();
                      handleAddTag();
                    }
                  }}
                  className={`bg-transparent text-xs placeholder:text-stone-400 focus:outline-none w-28 ${
                    isDarkPaper ? 'text-stone-300' : 'text-stone-700'
                  }`}
                />
              </div>
            </div>

            {/* Attached Images Preview Grid */}
            {images.length > 0 && (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2">
                {images.map((imgUrl, index) => (
                  <div
                    key={index}
                    className="relative group rounded-xl overflow-hidden border border-stone-200/80 bg-stone-100 aspect-4/3 shadow-xs"
                  >
                    <img
                      src={imgUrl}
                      alt={`Attached image ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                    <button
                      type="button"
                      onClick={() => removeImage(index)}
                      className="absolute top-2 right-2 p-1.5 bg-stone-900/80 text-white rounded-lg opacity-0 group-hover:opacity-100 transition-opacity hover:bg-rose-600"
                      title="Remove image"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Main Content Area */}
            <textarea
              id="editor-content-textarea"
              ref={textareaRef}
              rows={16}
              placeholder="What is on your mind today? Write freely, without judgment or restraint..."
              value={content}
              onChange={(e) => {
                setContent(e.target.value);
                setSaveStatus('modified');
              }}
              className={`w-full bg-transparent resize-none font-serif text-base sm:text-lg leading-relaxed focus:outline-none placeholder:text-stone-300 ${
                isDarkPaper ? 'text-stone-200 placeholder:text-stone-600' : 'text-stone-800'
              }`}
            />
          </div>

          {/* Paper Footer */}
          <div className={`px-6 sm:px-12 py-4 border-t flex items-center justify-between text-xs ${
            isDarkPaper ? 'border-stone-800 text-stone-500' : 'border-stone-100 text-stone-400'
          }`}>
            <div className="flex items-center gap-2">
              <span className="inline-block w-2 h-2 rounded-full bg-emerald-500" />
              <span>
                {saveStatus === 'saved' 
                  ? 'All changes saved' 
                  : saveStatus === 'modified' 
                  ? 'Unsaved changes' 
                  : 'Ready'}
              </span>
            </div>
            <span>Private & Local storage</span>
          </div>
        </div>
      </div>
    </div>
  );
};
