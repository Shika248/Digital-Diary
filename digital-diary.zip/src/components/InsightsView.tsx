import React from 'react';
import { 
  Flame, 
  BookOpen, 
  PenTool, 
  Clock, 
  Smile, 
  Tag as TagIcon, 
  TrendingUp, 
  Award,
  Sun,
  Moon
} from 'lucide-react';
import { DiaryEntry } from '../types';
import { MOODS } from '../utils/moods';

interface InsightsViewProps {
  entries: DiaryEntry[];
  streak: { current: number; longest: number };
}

export const InsightsView: React.FC<InsightsViewProps> = ({ entries, streak }) => {
  // Total statistics
  const totalEntries = entries.length;
  const totalWords = entries.reduce((acc, e) => acc + (e.wordCount || 0), 0);
  const avgWords = totalEntries > 0 ? Math.round(totalWords / totalEntries) : 0;
  const totalReadingMinutes = Math.round(totalWords / 200);

  // Mood frequency breakdown
  const moodCounts: Record<string, number> = {};
  entries.forEach((e) => {
    moodCounts[e.mood] = (moodCounts[e.mood] || 0) + 1;
  });

  const sortedMoods = Object.entries(moodCounts).sort((a, b) => b[1] - a[1]);

  // Tag frequency breakdown
  const tagCounts: Record<string, number> = {};
  entries.forEach((e) => {
    (e.tags || []).forEach((tag) => {
      tagCounts[tag] = (tagCounts[tag] || 0) + 1;
    });
  });

  const sortedTags = Object.entries(tagCounts).sort((a, b) => b[1] - a[1]);

  // Time of day breakdown
  let morningCount = 0; // 05:00 - 11:59
  let afternoonCount = 0; // 12:00 - 16:59
  let eveningCount = 0; // 17:00 - 21:59
  let nightCount = 0; // 22:00 - 04:59

  entries.forEach((e) => {
    const hour = parseInt(e.time?.split(':')[0] || '12', 10);
    if (hour >= 5 && hour < 12) morningCount++;
    else if (hour >= 12 && hour < 17) afternoonCount++;
    else if (hour >= 17 && hour < 22) eveningCount++;
    else nightCount++;
  });

  return (
    <div id="insights-container" className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Header Banner */}
      <div>
        <h2 className="font-serif font-bold text-2xl sm:text-3xl text-stone-900 tracking-tight">
          Journal Insights & Growth
        </h2>
        <p className="text-xs sm:text-sm text-stone-500 mt-1">
          A panoramic view of your reflections, emotional rhythm, and writing practice.
        </p>
      </div>

      {/* Top 4 Key Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Streak Card */}
        <div className="bg-white rounded-2xl border border-stone-200/80 p-5 shadow-xs">
          <div className="flex items-center justify-between text-amber-600 mb-2">
            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">Current Streak</span>
            <Flame className="w-5 h-5 fill-amber-500 text-amber-600" />
          </div>
          <div className="text-3xl font-serif font-bold text-stone-900">
            {streak.current} <span className="text-sm font-sans font-normal text-stone-500">days</span>
          </div>
          <p className="text-xs text-stone-400 mt-2">
            Best streak: <span className="font-medium text-stone-700">{streak.longest} days</span>
          </p>
        </div>

        {/* Total Entries Card */}
        <div className="bg-white rounded-2xl border border-stone-200/80 p-5 shadow-xs">
          <div className="flex items-center justify-between text-stone-700 mb-2">
            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">Memories</span>
            <BookOpen className="w-5 h-5 text-stone-600" />
          </div>
          <div className="text-3xl font-serif font-bold text-stone-900">
            {totalEntries} <span className="text-sm font-sans font-normal text-stone-500">entries</span>
          </div>
          <p className="text-xs text-stone-400 mt-2">
            Captured moments
          </p>
        </div>

        {/* Total Words Card */}
        <div className="bg-white rounded-2xl border border-stone-200/80 p-5 shadow-xs">
          <div className="flex items-center justify-between text-stone-700 mb-2">
            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">Words Written</span>
            <PenTool className="w-5 h-5 text-stone-600" />
          </div>
          <div className="text-3xl font-serif font-bold text-stone-900">
            {totalWords.toLocaleString()}
          </div>
          <p className="text-xs text-stone-400 mt-2">
            ~{avgWords} words / entry
          </p>
        </div>

        {/* Reading Time */}
        <div className="bg-white rounded-2xl border border-stone-200/80 p-5 shadow-xs">
          <div className="flex items-center justify-between text-stone-700 mb-2">
            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">Reading Volume</span>
            <Clock className="w-5 h-5 text-stone-600" />
          </div>
          <div className="text-3xl font-serif font-bold text-stone-900">
            {totalReadingMinutes} <span className="text-sm font-sans font-normal text-stone-500">min</span>
          </div>
          <p className="text-xs text-stone-400 mt-2">
            Equivalent reading time
          </p>
        </div>
      </div>

      {/* Mood Distribution & Writing Cadence */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Mood Distribution Card */}
        <div className="bg-white rounded-2xl border border-stone-200/80 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-serif font-bold text-lg text-stone-900 flex items-center gap-2">
              <Smile className="w-4 h-4 text-stone-500" />
              <span>Emotional Resonance</span>
            </h3>
            <span className="text-xs text-stone-400">{totalEntries} logs</span>
          </div>

          {totalEntries === 0 ? (
            <p className="text-xs text-stone-400 py-6 text-center">No mood data recorded yet.</p>
          ) : (
            <div className="space-y-3 pt-2">
              {sortedMoods.map(([moodKey, count]) => {
                const mood = MOODS[moodKey as any] || MOODS.calm;
                const percentage = Math.round((count / totalEntries) * 100);
                return (
                  <div key={moodKey} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="flex items-center gap-1.5 font-medium text-stone-700">
                        <span>{mood.emoji}</span>
                        <span>{mood.label}</span>
                      </span>
                      <span className="text-stone-500">
                        {count} ({percentage}%)
                      </span>
                    </div>
                    <div className="w-full h-2 bg-stone-100 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{
                          width: `${percentage}%`,
                          backgroundColor: mood.dotColor,
                        }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Writing Cadence / Time of Day */}
        <div className="bg-white rounded-2xl border border-stone-200/80 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-serif font-bold text-lg text-stone-900 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-stone-500" />
              <span>Writing Rhythm</span>
            </h3>
            <span className="text-xs text-stone-400">Time of Day</span>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-2">
            <div className="p-3.5 rounded-xl border border-stone-100 bg-stone-50/50">
              <div className="flex items-center gap-1.5 text-xs text-amber-700 font-medium mb-1">
                <Sun className="w-3.5 h-3.5" />
                <span>Morning</span>
              </div>
              <div className="text-2xl font-serif font-bold text-stone-900">{morningCount}</div>
              <p className="text-[11px] text-stone-400 mt-0.5">5:00 AM - 12:00 PM</p>
            </div>

            <div className="p-3.5 rounded-xl border border-stone-100 bg-stone-50/50">
              <div className="flex items-center gap-1.5 text-xs text-sky-700 font-medium mb-1">
                <Sun className="w-3.5 h-3.5" />
                <span>Afternoon</span>
              </div>
              <div className="text-2xl font-serif font-bold text-stone-900">{afternoonCount}</div>
              <p className="text-[11px] text-stone-400 mt-0.5">12:00 PM - 5:00 PM</p>
            </div>

            <div className="p-3.5 rounded-xl border border-stone-100 bg-stone-50/50">
              <div className="flex items-center gap-1.5 text-xs text-violet-700 font-medium mb-1">
                <Moon className="w-3.5 h-3.5" />
                <span>Evening</span>
              </div>
              <div className="text-2xl font-serif font-bold text-stone-900">{eveningCount}</div>
              <p className="text-[11px] text-stone-400 mt-0.5">5:00 PM - 10:00 PM</p>
            </div>

            <div className="p-3.5 rounded-xl border border-stone-100 bg-stone-50/50">
              <div className="flex items-center gap-1.5 text-xs text-indigo-700 font-medium mb-1">
                <Moon className="w-3.5 h-3.5" />
                <span>Night</span>
              </div>
              <div className="text-2xl font-serif font-bold text-stone-900">{nightCount}</div>
              <p className="text-[11px] text-stone-400 mt-0.5">10:00 PM - 5:00 AM</p>
            </div>
          </div>
        </div>
      </div>

      {/* Frequent Themes & Tags */}
      <div className="bg-white rounded-2xl border border-stone-200/80 p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-serif font-bold text-lg text-stone-900 flex items-center gap-2">
            <TagIcon className="w-4 h-4 text-stone-500" />
            <span>Recurring Themes & Keywords</span>
          </h3>
          <span className="text-xs text-stone-400">{sortedTags.length} distinct tags</span>
        </div>

        {sortedTags.length === 0 ? (
          <p className="text-xs text-stone-400 py-4 text-center">
            Add tags to your entries (e.g. #gratitude, #work, #ideas) to see them mapped here.
          </p>
        ) : (
          <div className="flex flex-wrap gap-2 pt-1">
            {sortedTags.map(([tag, count]) => (
              <div
                key={tag}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200/80 text-stone-800 text-xs font-medium transition-colors"
              >
                <span>#{tag}</span>
                <span className="px-1.5 py-0.2 bg-white text-stone-600 rounded-full text-[10px] font-semibold border border-stone-200">
                  {count}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
