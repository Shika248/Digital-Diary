import React, { useState } from 'react';
import { X, Sparkles, Plus, ArrowRight } from 'lucide-react';
import { JOURNAL_PROMPTS, JournalPrompt } from '../data/prompts';

interface PromptsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectPrompt: (promptText: string) => void;
}

export const PromptsModal: React.FC<PromptsModalProps> = ({
  isOpen,
  onClose,
  onSelectPrompt,
}) => {
  if (!isOpen) return null;

  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', 'Gratitude', 'Reflection', 'Clarity', 'Growth', 'Creativity'];

  const filteredPrompts =
    selectedCategory === 'All'
      ? JOURNAL_PROMPTS
      : JOURNAL_PROMPTS.filter((p) => p.category === selectedCategory);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div 
        id="prompts-modal-card" 
        className="w-full max-w-2xl bg-white rounded-2xl shadow-xl border border-stone-200 overflow-hidden flex flex-col max-h-[85vh]"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-200/80 bg-stone-50/70">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-serif font-bold text-lg text-stone-900">Writing Inspiration</h3>
              <p className="text-xs text-stone-500">Thoughtful questions to kindle your inner reflection</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-700 hover:bg-stone-200/60 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Category Pill Bar */}
        <div className="px-6 py-3 border-b border-stone-100 flex items-center gap-1.5 overflow-x-auto no-scrollbar bg-white">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-colors ${
                selectedCategory === cat
                  ? 'bg-stone-900 text-white'
                  : 'bg-stone-100 text-stone-600 hover:bg-stone-200/80'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Prompts list */}
        <div className="p-6 overflow-y-auto space-y-3 flex-1">
          {filteredPrompts.map((item) => (
            <div
              key={item.id}
              onClick={() => {
                onSelectPrompt(item.prompt);
                onClose();
              }}
              className="group p-4 rounded-xl border border-stone-200/80 hover:border-amber-300 bg-stone-50/50 hover:bg-amber-50/30 transition-all cursor-pointer flex items-start justify-between gap-4"
            >
              <div className="space-y-1">
                <span className="text-[10px] font-bold tracking-wider uppercase px-2 py-0.5 rounded bg-stone-200/70 text-stone-700">
                  {item.category}
                </span>
                <p className="font-serif text-stone-800 text-sm sm:text-base leading-relaxed group-hover:text-amber-950 transition-colors pt-1">
                  "{item.prompt}"
                </p>
              </div>

              <button
                className="shrink-0 flex items-center gap-1 px-3 py-1.5 bg-white border border-stone-200 text-xs font-medium text-stone-700 rounded-lg group-hover:bg-amber-900 group-hover:text-white group-hover:border-amber-900 transition-colors"
              >
                <span>Use</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
