import React, { useState, useEffect } from 'react';
import { Lock, Delete, KeyRound, BookOpen } from 'lucide-react';

interface LockScreenProps {
  correctPin: string;
  authorName: string;
  onUnlock: () => void;
  onResetPin: () => void;
}

export const LockScreen: React.FC<LockScreenProps> = ({
  correctPin,
  authorName,
  onUnlock,
  onResetPin,
}) => {
  const [pinInput, setPinInput] = useState('');
  const [isError, setIsError] = useState(false);

  // Handle keyboard typing
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (/^[0-9]$/.test(e.key)) {
        if (pinInput.length < 4) {
          handleDigitPress(e.key);
        }
      } else if (e.key === 'Backspace') {
        handleBackspace();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [pinInput]);

  const handleDigitPress = (digit: string) => {
    if (pinInput.length >= 4) return;

    const next = pinInput + digit;
    setPinInput(next);
    setIsError(false);

    if (next.length === 4) {
      if (next === correctPin) {
        setTimeout(() => {
          onUnlock();
        }, 150);
      } else {
        setTimeout(() => {
          setIsError(true);
          setPinInput('');
        }, 200);
      }
    }
  };

  const handleBackspace = () => {
    setPinInput((prev) => prev.slice(0, -1));
    setIsError(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-stone-900 text-stone-100 flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-sm flex flex-col items-center text-center space-y-6">
        {/* Book / Lock Icon */}
        <div className="w-16 h-16 rounded-2xl bg-stone-800 border border-stone-700 flex items-center justify-center shadow-lg">
          <Lock className="w-7 h-7 text-amber-400" />
        </div>

        {/* Title */}
        <div>
          <h2 className="font-serif font-bold text-2xl text-stone-100 tracking-tight">
            {authorName ? `${authorName}'s Journal` : 'Digital Diary'}
          </h2>
          <p className="text-xs text-stone-400 mt-1">
            Enter 4-digit passcode to unlock your memories
          </p>
        </div>

        {/* 4-dot PIN indicator with subtle shake on error */}
        <div className={`flex items-center gap-4 my-2 ${isError ? 'animate-shake' : ''}`}>
          {[0, 1, 2, 3].map((index) => {
            const isFilled = pinInput.length > index;
            return (
              <div
                key={index}
                className={`w-4 h-4 rounded-full border-2 transition-all duration-200 ${
                  isFilled
                    ? 'bg-amber-400 border-amber-400 scale-110'
                    : isError
                    ? 'border-rose-500'
                    : 'border-stone-600 bg-stone-800'
                }`}
              />
            );
          })}
        </div>

        {isError && (
          <p className="text-xs font-medium text-rose-400 animate-in fade-in">
            Incorrect passcode. Try again.
          </p>
        )}

        {/* Numeric Keypad */}
        <div className="grid grid-cols-3 gap-3 w-full max-w-[280px] pt-4">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
            <button
              key={digit}
              type="button"
              onClick={() => handleDigitPress(digit)}
              className="h-14 rounded-2xl bg-stone-800/80 hover:bg-stone-700/80 active:bg-stone-600 border border-stone-700 text-stone-100 text-xl font-medium flex items-center justify-center transition-colors focus:outline-none"
            >
              {digit}
            </button>
          ))}

          {/* Empty spacer or Forgot */}
          <div className="flex items-center justify-center">
            {/* Blank */}
          </div>

          <button
            type="button"
            onClick={() => handleDigitPress('0')}
            className="h-14 rounded-2xl bg-stone-800/80 hover:bg-stone-700/80 active:bg-stone-600 border border-stone-700 text-stone-100 text-xl font-medium flex items-center justify-center transition-colors focus:outline-none"
          >
            0
          </button>

          <button
            type="button"
            onClick={handleBackspace}
            className="h-14 rounded-2xl bg-stone-800/40 hover:bg-stone-800 active:bg-stone-700 text-stone-400 hover:text-stone-200 flex items-center justify-center transition-colors focus:outline-none"
            title="Backspace"
          >
            <Delete className="w-5 h-5" />
          </button>
        </div>

        {/* Emergency reset helper */}
        <div className="pt-4">
          <button
            type="button"
            onClick={() => {
              if (
                confirm(
                  'Forgot your PIN? Confirming will reset your security passcode so you can access your journal.'
                )
              ) {
                onResetPin();
              }
            }}
            className="text-[11px] text-stone-500 hover:text-stone-400 underline transition-colors"
          >
            Forgot Passcode?
          </button>
        </div>
      </div>
    </div>
  );
};
