import React, { useState } from 'react';
import { 
  X, 
  Edit3, 
  Star, 
  Trash2, 
  Printer, 
  Share2, 
  Download, 
  Calendar as CalendarIcon, 
  Clock, 
  MapPin, 
  ChevronLeft, 
  ChevronRight,
  ZoomIn
} from 'lucide-react';
import { DiaryEntry } from '../types';
import { MOODS } from '../utils/moods';

interface EntryDetailModalProps {
  entry: DiaryEntry | null;
  onClose: () => void;
  onEdit: (entry: DiaryEntry) => void;
  onDelete: (id: string) => void;
  onToggleFavorite: (id: string) => void;
  onPrev?: () => void;
  onNext?: () => void;
  hasPrev?: boolean;
  hasNext?: boolean;
}

export const EntryDetailModal: React.FC<EntryDetailModalProps> = ({
  entry,
  onClose,
  onEdit,
  onDelete,
  onToggleFavorite,
  onPrev,
  onNext,
  hasPrev,
  hasNext,
}) => {
  if (!entry) return null;

  const [selectedZoomImage, setSelectedZoomImage] = useState<string | null>(null);
  const mood = MOODS[entry.mood] || MOODS.calm;

  const dateFormatted = new Date(`${entry.date}T${entry.time || '12:00'}`).toLocaleDateString(
    undefined,
    {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
      year: 'numeric',
    }
  );

  // Markdown renderer into clean HTML elements
  const renderFormattedContent = (rawText: string) => {
    if (!rawText) return <p className="text-stone-400 italic">No written content.</p>;

    const lines = rawText.split('\n');
    return lines.map((line, idx) => {
      // Horizontal Rule
      if (line.trim() === '---' || line.trim() === '***') {
        return <hr key={idx} className="my-6 border-stone-200" />;
      }

      // Heading 1
      if (line.startsWith('# ')) {
        return (
          <h2 key={idx} className="font-serif font-bold text-2xl text-stone-900 mt-6 mb-3">
            {line.substring(2)}
          </h2>
        );
      }

      // Heading 2 or 3
      if (line.startsWith('## ') || line.startsWith('### ')) {
        const text = line.replace(/^#{2,3}\s/, '');
        return (
          <h3 key={idx} className="font-serif font-semibold text-xl text-stone-800 mt-5 mb-2">
            {text}
          </h3>
        );
      }

      // Blockquote
      if (line.startsWith('> ')) {
        return (
          <blockquote
            key={idx}
            className="border-l-3 border-amber-600 pl-4 py-1.5 my-3 italic text-stone-700 bg-amber-50/40 rounded-r-lg font-serif"
          >
            {line.substring(2)}
          </blockquote>
        );
      }

      // Checklist item
      if (line.startsWith('- [ ] ') || line.startsWith('- [x] ')) {
        const isChecked = line.startsWith('- [x] ');
        const text = line.substring(6);
        return (
          <div key={idx} className="flex items-center gap-2.5 my-1.5 text-stone-700 text-sm sm:text-base">
            <span
              className={`w-4 h-4 rounded flex items-center justify-center text-xs border ${
                isChecked
                  ? 'bg-amber-800 border-amber-800 text-white'
                  : 'border-stone-300 bg-white'
              }`}
            >
              {isChecked ? '✓' : ''}
            </span>
            <span className={isChecked ? 'line-through text-stone-400' : ''}>{text}</span>
          </div>
        );
      }

      // Bullet List
      if (line.startsWith('- ') || line.startsWith('* ')) {
        return (
          <li key={idx} className="ml-5 list-disc text-stone-700 my-1 text-sm sm:text-base">
            {line.substring(2)}
          </li>
        );
      }

      // Empty line
      if (!line.trim()) {
        return <div key={idx} className="h-3" />;
      }

      // Standard paragraph with inline bold / italic parsing
      return (
        <p key={idx} className="text-stone-800 font-serif text-base sm:text-lg leading-relaxed mb-3">
          {line}
        </p>
      );
    });
  };

  const handlePrint = () => {
    window.print();
  };

  const handleExportSingle = () => {
    let md = `# ${entry.title || 'Untitled'}\n`;
    md += `Date: ${entry.date} at ${entry.time}\n`;
    md += `Mood: ${entry.mood} | Weather: ${entry.weather || 'N/A'}\n\n`;
    md += entry.content;

    const blob = new Blob([md], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${entry.date}-${entry.title ? entry.title.toLowerCase().replace(/\s+/g, '-') : 'entry'}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-stone-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div 
        id="entry-detail-card" 
        className="relative w-full max-w-3xl max-h-[90vh] bg-white rounded-2xl shadow-xl flex flex-col border border-stone-200 overflow-hidden"
      >
        {/* Top Header Controls */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-200/80 bg-stone-50/70">
          {/* Navigation between entries */}
          <div className="flex items-center gap-1">
            {hasPrev && (
              <button
                onClick={onPrev}
                className="p-1.5 rounded-lg text-stone-600 hover:bg-stone-200/60 transition-colors"
                title="Previous entry"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
            )}
            {hasNext && (
              <button
                onClick={onNext}
                className="p-1.5 rounded-lg text-stone-600 hover:bg-stone-200/60 transition-colors"
                title="Next entry"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            )}
            <span className="text-xs text-stone-500 ml-2 font-medium">Memory Viewer</span>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => onToggleFavorite(entry.id)}
              className="p-2 text-stone-500 hover:text-amber-500 hover:bg-stone-100 rounded-xl transition-colors"
              title={entry.isFavorite ? 'Unfavorite' : 'Favorite'}
            >
              <Star className={`w-4 h-4 ${entry.isFavorite ? 'fill-amber-500 text-amber-500' : ''}`} />
            </button>

            <button
              onClick={handlePrint}
              className="p-2 text-stone-500 hover:text-stone-800 hover:bg-stone-100 rounded-xl transition-colors"
              title="Print memory"
            >
              <Printer className="w-4 h-4" />
            </button>

            <button
              onClick={handleExportSingle}
              className="p-2 text-stone-500 hover:text-stone-800 hover:bg-stone-100 rounded-xl transition-colors"
              title="Export as Markdown"
            >
              <Download className="w-4 h-4" />
            </button>

            <button
              onClick={() => onEdit(entry)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-medium transition-colors"
              title="Edit memory"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Edit</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded-xl transition-colors"
              title="Close viewer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Journal Reading Body */}
        <div className="flex-1 overflow-y-auto px-6 sm:px-12 py-8 space-y-6">
          {/* Metadata banner */}
          <div className="border-b border-stone-100 pb-5 space-y-3">
            <div className="flex flex-wrap items-center gap-3 text-xs text-stone-500">
              <span className="flex items-center gap-1 font-medium text-stone-700">
                <CalendarIcon className="w-3.5 h-3.5 text-stone-400" />
                {dateFormatted}
              </span>
              <span className="text-stone-300">·</span>
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-stone-400" />
                {entry.time}
              </span>

              {entry.location && (
                <>
                  <span className="text-stone-300">·</span>
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-stone-400" />
                    {entry.location}
                  </span>
                </>
              )}

              {/* Mood Pill */}
              <span
                className={`ml-auto inline-flex items-center gap-1 px-3 py-0.5 rounded-full text-xs font-medium border ${mood.bgClass} ${mood.textClass} ${mood.borderClass}`}
              >
                <span>{mood.emoji}</span>
                <span>{mood.label}</span>
              </span>
            </div>

            {/* Title */}
            <h1 className="font-serif font-bold text-2xl sm:text-3xl lg:text-4xl text-stone-900 tracking-tight leading-snug">
              {entry.title || 'Untitled Entry'}
            </h1>

            {/* Tags */}
            {entry.tags && entry.tags.length > 0 && (
              <div className="flex flex-wrap gap-1.5 pt-1">
                {entry.tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-2.5 py-0.5 bg-stone-100 text-stone-600 rounded-md text-xs font-medium"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Attached Photo Gallery */}
          {entry.images && entry.images.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 my-4">
              {entry.images.map((img, i) => (
                <div
                  key={i}
                  onClick={() => setSelectedZoomImage(img)}
                  className="relative group rounded-xl overflow-hidden border border-stone-200 aspect-4/3 cursor-pointer shadow-xs"
                >
                  <img src={img} alt="Attached memory" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-stone-900/20 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity text-white">
                    <ZoomIn className="w-5 h-5" />
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Main Body Prose */}
          <div className="prose prose-stone max-w-none py-2 font-serif">
            {renderFormattedContent(entry.content)}
          </div>
        </div>

        {/* Footer info */}
        <div className="px-6 py-3 border-t border-stone-100 bg-stone-50/60 flex items-center justify-between text-xs text-stone-500">
          <span>{entry.wordCount || 0} words · ~{entry.readingTime || 1} min read</span>
          <button
            onClick={() => {
              if (confirm('Delete this entry permanently?')) {
                onDelete(entry.id);
                onClose();
              }
            }}
            className="text-stone-400 hover:text-rose-600 flex items-center gap-1 transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Delete</span>
          </button>
        </div>
      </div>

      {/* Image Zoom Modal */}
      {selectedZoomImage && (
        <div
          className="fixed inset-0 z-60 bg-black/90 flex items-center justify-center p-4"
          onClick={() => setSelectedZoomImage(null)}
        >
          <img
            src={selectedZoomImage}
            alt="Enlarged view"
            className="max-w-full max-h-[90vh] rounded-lg object-contain shadow-2xl"
          />
        </div>
      )}
    </div>
  );
};
