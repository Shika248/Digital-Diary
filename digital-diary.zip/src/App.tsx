import React, { useState, useEffect } from 'react';
import { DiaryEntry, ViewMode, DiarySettings } from './types';
import { 
  loadEntries, 
  saveEntries, 
  loadSettings, 
  saveSettings, 
  loadIsLocked, 
  saveIsLocked,
  calculateStreak,
  exportEntriesAsMarkdown
} from './utils/storage';
import { Header } from './components/Header';
import { EntryList } from './components/EntryList';
import { Editor } from './components/Editor';
import { CalendarView } from './components/CalendarView';
import { InsightsView } from './components/InsightsView';
import { EntryDetailModal } from './components/EntryDetailModal';
import { SettingsModal } from './components/SettingsModal';
import { PromptsModal } from './components/PromptsModal';
import { LockScreen } from './components/LockScreen';

export default function App() {
  const [entries, setEntries] = useState<DiaryEntry[]>(() => loadEntries());
  const [settings, setSettings] = useState<DiarySettings>(() => loadSettings());
  const [isLocked, setIsLocked] = useState<boolean>(() => {
    const loadedLock = loadIsLocked();
    const loadedSet = loadSettings();
    return loadedLock && loadedSet.hasPin && Boolean(loadedSet.pin);
  });

  const [currentView, setCurrentView] = useState<ViewMode>('timeline');
  const [editingEntry, setEditingEntry] = useState<DiaryEntry | null>(null);
  const [initialDateForWriting, setInitialDateForWriting] = useState<string | undefined>(undefined);
  const [readingEntry, setReadingEntry] = useState<DiaryEntry | null>(null);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isPromptsOpen, setIsPromptsOpen] = useState(false);

  // Sync entries to localStorage
  useEffect(() => {
    saveEntries(entries);
  }, [entries]);

  // Sync settings to localStorage
  useEffect(() => {
    saveSettings(settings);
  }, [settings]);

  // Sync lock state
  useEffect(() => {
    saveIsLocked(isLocked);
  }, [isLocked]);

  const streak = calculateStreak(entries);

  // Handlers
  const handleSaveEntry = (savedEntry: DiaryEntry) => {
    setEntries((prev) => {
      const exists = prev.some((e) => e.id === savedEntry.id);
      if (exists) {
        return prev.map((e) => (e.id === savedEntry.id ? savedEntry : e));
      } else {
        return [savedEntry, ...prev];
      }
    });
    setEditingEntry(null);
    setInitialDateForWriting(undefined);
    setCurrentView('timeline');
  };

  const handleDeleteEntry = (id: string) => {
    setEntries((prev) => prev.filter((e) => e.id !== id));
    if (editingEntry?.id === id) {
      setEditingEntry(null);
      setCurrentView('timeline');
    }
    if (readingEntry?.id === id) {
      setReadingEntry(null);
    }
  };

  const handleToggleFavorite = (id: string) => {
    setEntries((prev) =>
      prev.map((e) => (e.id === id ? { ...e, isFavorite: !e.isFavorite } : e))
    );
    if (readingEntry?.id === id) {
      setReadingEntry((prev) => (prev ? { ...prev, isFavorite: !prev.isFavorite } : null));
    }
  };

  const handleNewEntry = (forDate?: string) => {
    setEditingEntry(null);
    setInitialDateForWriting(forDate);
    setCurrentView('write');
  };

  const handleEditEntry = (entry: DiaryEntry) => {
    setEditingEntry(entry);
    setInitialDateForWriting(entry.date);
    setReadingEntry(null);
    setCurrentView('write');
  };

  const handleSelectEntry = (entry: DiaryEntry) => {
    setReadingEntry(entry);
  };

  const handleQuickExport = () => {
    exportEntriesAsMarkdown(entries, settings.authorName);
  };

  const handleLock = () => {
    if (settings.hasPin && settings.pin) {
      setIsLocked(true);
    }
  };

  const handleUnlock = () => {
    setIsLocked(false);
  };

  const handleResetPin = () => {
    setSettings((prev) => ({ ...prev, pin: null, hasPin: false }));
    setIsLocked(false);
  };

  const handleUsePrompt = (promptText: string) => {
    if (currentView === 'write' && editingEntry) {
      // If already editing, append prompt to content
      setEditingEntry((prev) =>
        prev
          ? {
              ...prev,
              content: prev.content
                ? `${prev.content}\n\n> Prompt: ${promptText}\n\n`
                : `> Prompt: ${promptText}\n\n`,
            }
          : null
      );
    } else {
      // Start a brand new entry initialized with this prompt
      const newEntry: DiaryEntry = {
        id: `entry-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
        title: `Reflection on "${promptText.substring(0, 35)}..."`,
        content: `> Prompt: ${promptText}\n\n`,
        date: new Date().toISOString().split('T')[0],
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }),
        createdAt: Date.now(),
        updatedAt: Date.now(),
        mood: 'reflective',
        weather: 'sunny',
        tags: ['prompt', 'reflection'],
        isFavorite: false,
        wordCount: 0,
        readingTime: 1,
      };
      setEditingEntry(newEntry);
      setCurrentView('write');
    }
  };

  // Previous and Next entry for reader modal
  const currentReadingIndex = readingEntry
    ? entries.findIndex((e) => e.id === readingEntry.id)
    : -1;
  const hasPrev = currentReadingIndex > 0;
  const hasNext = currentReadingIndex >= 0 && currentReadingIndex < entries.length - 1;

  const handlePrevReading = () => {
    if (hasPrev) {
      setReadingEntry(entries[currentReadingIndex - 1]);
    }
  };

  const handleNextReading = () => {
    if (hasNext) {
      setReadingEntry(entries[currentReadingIndex + 1]);
    }
  };

  // If locked with PIN, render security lock screen
  if (isLocked && settings.pin) {
    return (
      <LockScreen
        correctPin={settings.pin}
        authorName={settings.authorName}
        onUnlock={handleUnlock}
        onResetPin={handleResetPin}
      />
    );
  }

  return (
    <div className="min-h-screen bg-stone-50 text-stone-900 flex flex-col selection:bg-amber-100 selection:text-amber-900">
      {/* Top Header (omitted only in full write mode if desired, or kept for seamless navigation) */}
      {currentView !== 'write' && (
        <Header
          currentView={currentView}
          onViewChange={(view) => setCurrentView(view)}
          onNewEntry={() => handleNewEntry()}
          onLock={handleLock}
          onOpenSettings={() => setIsSettingsOpen(true)}
          onQuickExport={handleQuickExport}
          streak={streak}
          settings={settings}
          entriesCount={entries.length}
        />
      )}

      {/* Main View Area */}
      <main className="flex-1">
        {currentView === 'write' ? (
          <Editor
            entry={editingEntry}
            onSave={handleSaveEntry}
            onDelete={handleDeleteEntry}
            onCancel={() => {
              setEditingEntry(null);
              setCurrentView('timeline');
            }}
            onOpenPrompts={() => setIsPromptsOpen(true)}
            initialDate={initialDateForWriting}
          />
        ) : currentView === 'calendar' ? (
          <CalendarView
            entries={entries}
            onSelectEntry={handleSelectEntry}
            onEditEntry={handleEditEntry}
            onCreateForDate={(dateStr) => handleNewEntry(dateStr)}
          />
        ) : currentView === 'insights' ? (
          <InsightsView entries={entries} streak={streak} />
        ) : (
          <EntryList
            entries={entries}
            onSelectEntry={handleSelectEntry}
            onEditEntry={handleEditEntry}
            onDeleteEntry={handleDeleteEntry}
            onToggleFavorite={handleToggleFavorite}
            onNewEntry={() => handleNewEntry()}
            onOpenPrompts={() => setIsPromptsOpen(true)}
          />
        )}
      </main>

      {/* Reading Mode Modal */}
      {readingEntry && (
        <EntryDetailModal
          entry={readingEntry}
          onClose={() => setReadingEntry(null)}
          onEdit={handleEditEntry}
          onDelete={handleDeleteEntry}
          onToggleFavorite={handleToggleFavorite}
          onPrev={handlePrevReading}
          onNext={handleNextReading}
          hasPrev={hasPrev}
          hasNext={hasNext}
        />
      )}

      {/* Settings & Privacy Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        entries={entries}
        onUpdateSettings={(newSettings) => setSettings(newSettings)}
        onRestoreEntries={(restoredEntries) => setEntries(restoredEntries)}
      />

      {/* Daily Writing Prompts Modal */}
      <PromptsModal
        isOpen={isPromptsOpen}
        onClose={() => setIsPromptsOpen(false)}
        onSelectPrompt={handleUsePrompt}
      />
    </div>
  );
}
