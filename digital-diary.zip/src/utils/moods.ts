import { MoodType, WeatherType } from '../types';

export interface MoodConfig {
  type: MoodType;
  label: string;
  emoji: string;
  bgClass: string;
  textClass: string;
  borderClass: string;
  dotColor: string;
}

export const MOODS: Record<MoodType, MoodConfig> = {
  joyful: {
    type: 'joyful',
    label: 'Joyful',
    emoji: '☀️',
    bgClass: 'bg-amber-50',
    textClass: 'text-amber-800',
    borderClass: 'border-amber-200',
    dotColor: '#f59e0b',
  },
  calm: {
    type: 'calm',
    label: 'Calm',
    emoji: '🌿',
    bgClass: 'bg-emerald-50',
    textClass: 'text-emerald-800',
    borderClass: 'border-emerald-200',
    dotColor: '#10b981',
  },
  inspired: {
    type: 'inspired',
    label: 'Inspired',
    emoji: '✨',
    bgClass: 'bg-violet-50',
    textClass: 'text-violet-800',
    borderClass: 'border-violet-200',
    dotColor: '#8b5cf6',
  },
  grateful: {
    type: 'grateful',
    label: 'Grateful',
    emoji: '🕊️',
    bgClass: 'bg-rose-50',
    textClass: 'text-rose-800',
    borderClass: 'border-rose-200',
    dotColor: '#f43f5e',
  },
  reflective: {
    type: 'reflective',
    label: 'Reflective',
    emoji: '🌊',
    bgClass: 'bg-sky-50',
    textClass: 'text-sky-800',
    borderClass: 'border-sky-200',
    dotColor: '#0ea5e9',
  },
  anxious: {
    type: 'anxious',
    label: 'Anxious',
    emoji: '🍂',
    bgClass: 'bg-orange-50',
    textClass: 'text-orange-800',
    borderClass: 'border-orange-200',
    dotColor: '#ea580c',
  },
  tired: {
    type: 'tired',
    label: 'Tired',
    emoji: '🌙',
    bgClass: 'bg-stone-100',
    textClass: 'text-stone-700',
    borderClass: 'border-stone-200',
    dotColor: '#78716c',
  },
  sad: {
    type: 'sad',
    label: 'Low',
    emoji: '🌧️',
    bgClass: 'bg-blue-50',
    textClass: 'text-blue-800',
    borderClass: 'border-blue-200',
    dotColor: '#3b82f6',
  },
};

export interface WeatherConfig {
  type: WeatherType;
  label: string;
  iconName: string;
}

export const WEATHERS: { type: WeatherType; label: string; icon: string }[] = [
  { type: 'sunny', label: 'Sunny', icon: 'Sun' },
  { type: 'partly-cloudy', label: 'Partly Cloudy', icon: 'CloudSun' },
  { type: 'cloudy', label: 'Overcast', icon: 'Cloud' },
  { type: 'rainy', label: 'Rainy', icon: 'CloudRain' },
  { type: 'windy', label: 'Breezy', icon: 'Wind' },
  { type: 'snowy', label: 'Snowy', icon: 'Snowflake' },
];
