import { DiaryEntry, DiarySettings } from '../types';
import { INITIAL_ENTRIES } from '../data/initialEntries';

const STORAGE_KEYS = {
  ENTRIES: 'digital_diary_entries_v1',
  SETTINGS: 'digital_diary_settings_v1',
  IS_LOCKED: 'digital_diary_is_locked_v1',
};

const DEFAULT_SETTINGS: DiarySettings = {
  authorName: 'Alex Morgan',
  pin: null,
  hasPin: false,
  paperTheme: 'classic',
  fontPreference: 'serif',
};

export const loadEntries = (): DiaryEntry[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ENTRIES);
    if (!raw) {
      // Seed with initial entries on first visit
      saveEntries(INITIAL_ENTRIES);
      return INITIAL_ENTRIES;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : INITIAL_ENTRIES;
  } catch (error) {
    console.error('Failed to load diary entries:', error);
    return INITIAL_ENTRIES;
  }
};

export const saveEntries = (entries: DiaryEntry[]): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.ENTRIES, JSON.stringify(entries));
  } catch (error) {
    console.error('Failed to save diary entries:', error);
  }
};

export const loadSettings = (): DiarySettings => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch (error) {
    console.error('Failed to load settings:', error);
    return DEFAULT_SETTINGS;
  }
};

export const saveSettings = (settings: DiarySettings): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  } catch (error) {
    console.error('Failed to save settings:', error);
  }
};

export const loadIsLocked = (): boolean => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.IS_LOCKED);
    return raw === 'true';
  } catch {
    return false;
  }
};

export const saveIsLocked = (locked: boolean): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.IS_LOCKED, locked ? 'true' : 'false');
  } catch {
    // ignore
  }
};

// Calculate writing streak (consecutive days)
export const calculateStreak = (entries: DiaryEntry[]): { current: number; longest: number } => {
  if (!entries || entries.length === 0) return { current: 0, longest: 0 };

  // Collect unique dates sorted descending
  const uniqueDates = Array.from(new Set(entries.map((e) => e.date))).sort(
    (a, b) => new Date(b).getTime() - new Date(a).getTime()
  );

  if (uniqueDates.length === 0) return { current: 0, longest: 0 };

  const todayStr = new Date().toISOString().split('T')[0];
  const yesterdayStr = new Date(Date.now() - 86400000).toISOString().split('T')[0];

  const hasWrittenToday = uniqueDates.includes(todayStr);
  const hasWrittenYesterday = uniqueDates.includes(yesterdayStr);

  let currentStreak = 0;

  // Streak is alive if written today or yesterday
  if (hasWrittenToday || hasWrittenYesterday) {
    let checkDate = new Date(hasWrittenToday ? todayStr : yesterdayStr);
    while (true) {
      const dateStr = checkDate.toISOString().split('T')[0];
      if (uniqueDates.includes(dateStr)) {
        currentStreak++;
        checkDate = new Date(checkDate.getTime() - 86400000);
      } else {
        break;
      }
    }
  }

  // Calculate longest streak
  let longestStreak = currentStreak;
  let currentRun = 0;
  // Sort ascending for longest streak detection
  const ascDates = [...uniqueDates].sort(
    (a, b) => new Date(a).getTime() - new Date(b).getTime()
  );

  for (let i = 0; i < ascDates.length; i++) {
    if (i === 0) {
      currentRun = 1;
    } else {
      const prevDate = new Date(ascDates[i - 1]);
      const currDate = new Date(ascDates[i]);
      const diffDays = Math.round((currDate.getTime() - prevDate.getTime()) / 86400000);

      if (diffDays === 1) {
        currentRun++;
      } else if (diffDays > 1) {
        currentRun = 1;
      }
    }
    if (currentRun > longestStreak) {
      longestStreak = currentRun;
    }
  }

  return { current: currentStreak, longest: longestStreak };
};

// Export all entries as clean JSON download
export const exportEntriesAsJSON = (entries: DiaryEntry[], authorName: string): void => {
  const exportData = {
    app: 'Digital Diary',
    author: authorName,
    exportedAt: new Date().toISOString(),
    totalEntries: entries.length,
    entries,
  };

  const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `digital-diary-backup-${new Date().toISOString().split('T')[0]}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};

// Export all entries as a compiled Markdown journal book
export const exportEntriesAsMarkdown = (entries: DiaryEntry[], authorName: string): void => {
  let md = `# ${authorName}'s Digital Diary\n`;
  md += `*Exported on ${new Date().toLocaleDateString(undefined, { dateStyle: 'full' })}*\n\n`;
  md += `---\n\n`;

  const sorted = [...entries].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  sorted.forEach((e) => {
    md += `## ${e.title || 'Untitled'}\n`;
    md += `**Date:** ${e.date} at ${e.time}  \n`;
    md += `**Mood:** ${e.mood} | **Weather:** ${e.weather || 'Unspecified'}  \n`;
    if (e.location) md += `**Location:** ${e.location}  \n`;
    if (e.tags && e.tags.length > 0) md += `**Tags:** ${e.tags.map((t) => `#${t}`).join(' ')}  \n`;
    md += `\n${e.content}\n\n`;
    md += `---\n\n`;
  });

  const blob = new Blob([md], { type: 'text/markdown' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `digital-diary-journal-${new Date().toISOString().split('T')[0]}.md`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};
