export type MoodType = 
  | 'joyful' 
  | 'calm' 
  | 'inspired' 
  | 'grateful' 
  | 'reflective' 
  | 'anxious' 
  | 'tired' 
  | 'sad';

export type WeatherType = 
  | 'sunny' 
  | 'partly-cloudy' 
  | 'cloudy' 
  | 'rainy' 
  | 'windy' 
  | 'snowy';

export interface DiaryEntry {
  id: string;
  title: string;
  content: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  createdAt: number;
  updatedAt: number;
  mood: MoodType;
  weather?: WeatherType;
  tags: string[];
  images?: string[]; // base64 or url
  isFavorite: boolean;
  location?: string;
  wordCount: number;
  readingTime: number; // in minutes
}

export type ViewMode = 'timeline' | 'calendar' | 'insights' | 'write';

export interface DiarySettings {
  authorName: string;
  pin: string | null;
  hasPin: boolean;
  paperTheme: 'classic' | 'warm-ivory' | 'slate' | 'midnight';
  fontPreference: 'serif' | 'sans';
}

export interface DiaryFilter {
  searchQuery: string;
  mood?: MoodType | 'all';
  tag?: string;
  onlyFavorites: boolean;
  startDate?: string;
  endDate?: string;
}
